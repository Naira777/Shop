import './App.css';
import {BrowserRouter, Route, Routes} from "react-router-dom";
import {useEffect} from "react";
import {useDispatch, useSelector} from "react-redux";
import {NavBar} from "./NavBar/NavBar";
import {Login} from "./pages/login/Login";
import {updateAdmin} from "./Redux/getAdmin/slice";
import {MainRouts} from "./Routes/MainRouts";

function App() {
    const {isAdmin} = useSelector(state => state.admin);
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(updateAdmin(localStorage.getItem('admin')))
    }, []);

    return (
        <div className='App'>
            <BrowserRouter>
                <NavBar/>
                <Routes>
                    {isAdmin ? MainRouts().map((item, index) => <Route key={index} path={item.path}
                                                                       element={item.element}/>)
                        : <Route path='/login' element={<Login/>}/>
                    }
                </Routes>
                <div id='loading'>
                    <div id='loading-gif'></div>
                </div>
            </BrowserRouter>
        </div>
    );
}

export default App;
