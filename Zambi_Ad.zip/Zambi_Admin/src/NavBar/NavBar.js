import * as React from 'react';
import {Login} from "./components/Login";
import {Collapse, List, ListItemButton, ListItemIcon, ListItemText, ListSubheader} from "@mui/material";
import {NavLink} from "react-router-dom";
import {NavBarList} from "./NavBarList";
import {useSelector} from "react-redux";
import {useState} from "react";

export function NavBar() {
    const [open, setOpen] = useState({});
    const handleClick = (i) => setOpen({...open, [`open${i}`]: !open[`open${i}`]})
    const {isAdmin} = useSelector(data => data.admin);

    return (
        <List
            component="nav"
            subheader={<ListSubheader component="div" id="nested-list-subheader">Admin panel</ListSubheader>}
        >
            <Login/>
            {isAdmin && NavBarList().map((item, i) => {
                return (
                    <React.Fragment key={i}>
                        {item.link && (
                            <NavLink to={item.link}>
                                <ListItemButton className='title'>
                                    <ListItemIcon>{item.icon}</ListItemIcon>
                                    <ListItemText primary={item.title}/>
                                </ListItemButton>
                            </NavLink>
                        )}
                        {!item.link && (
                            <>
                                <ListItemButton className='title' onClick={() => handleClick(i)}>
                                    <ListItemIcon>{item.icon}</ListItemIcon>
                                    <ListItemText primary={item.title}/>
                                </ListItemButton>
                                {item.component && (
                                    <Collapse in={open[`open${i}`]} timeout="auto" unmountOnExit>
                                        {item.component}
                                    </Collapse>
                                )}
                            </>
                        )}
                    </React.Fragment>
                )
            })}
        </List>
    );
}