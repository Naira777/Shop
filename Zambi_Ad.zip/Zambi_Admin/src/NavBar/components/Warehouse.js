import {List, ListItemButton, ListItemIcon, ListItemText} from "@mui/material";
import {NavLink} from "react-router-dom";
import * as React from "react";
import {useDispatch} from "react-redux";
import {changeWarehouseId} from "../../Redux/getWarehouse/slice";
import {ProductWarehouse} from "./ProductWarehouse";
import {AddCircleOutlineIcon, EditIcon} from "../../icons/Icons";
import {changeCategoryId} from "../../Redux/getCategory/slice";
import {changeAllProductId} from "../../Redux/getAllProduct/slice";
import {changeBrandId2} from "../../Redux/getBrand/slice";
import {changeProductId} from "../../Redux/getProduct/slice";

export function Warehouse() {
    const dispatch = useDispatch();
    const clearId = () => {
        dispatch(changeWarehouseId(null))
        dispatch(changeCategoryId(null))
        dispatch(changeAllProductId(null))
        dispatch(changeBrandId2(null))
        dispatch(changeProductId(null))
    }

    return (
        <>
            <NavLink to='/newWarehouse' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 3}}>
                        <ListItemIcon><AddCircleOutlineIcon/></ListItemIcon>
                        <ListItemText primary="New warehouse"/>
                    </ListItemButton>
                </List>
            </NavLink>
            <NavLink to='/editWarehouse' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 3}}>
                        <ListItemIcon><EditIcon/></ListItemIcon>
                        <ListItemText primary="Warehouse list"/>
                    </ListItemButton>
                </List>
            </NavLink>
            <ProductWarehouse/>
        </>
    );
}