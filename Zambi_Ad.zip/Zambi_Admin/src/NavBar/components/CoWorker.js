import * as React from "react";
import {List, ListItemButton, ListItemIcon, ListItemText} from "@mui/material";
import {NavLink} from "react-router-dom";
import {changeSlideId} from "../../Redux/getSlides/slice";
import {useDispatch} from "react-redux";
import {AddCircleOutlineIcon, EditIcon} from "../../icons/Icons";
import {changeCoWorkerId} from "../../Redux/getCoWorker/slice";

export function CoWorker() {
    const dispatch = useDispatch();
    const clearId = () => {
        dispatch(changeSlideId(null))
        dispatch(changeCoWorkerId(null));
    }
    return (
        <>
            <NavLink to='/newCoWorker' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><AddCircleOutlineIcon/></ListItemIcon>
                        <ListItemText primary="New Co Worker"/>
                    </ListItemButton>
                </List>
            </NavLink>
            <NavLink to='/editCoWorker' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><EditIcon/></ListItemIcon>
                        <ListItemText primary="Co Worker list"/>
                    </ListItemButton>
                </List>
            </NavLink>
        </>
    );
}