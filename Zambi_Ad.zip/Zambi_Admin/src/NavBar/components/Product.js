import * as React from "react";
import {NavLink} from "react-router-dom";
import {List, ListItemButton, ListItemIcon, ListItemText} from "@mui/material";
import {AddCircleOutlineIcon, EditIcon} from "../../icons/Icons";
import {changeBrandId2} from "../../Redux/getBrand/slice";
import {useDispatch} from "react-redux";
import {changeCategoryId} from "../../Redux/getCategory/slice";
import {changeAllProductId} from "../../Redux/getAllProduct/slice";


export function Product() {
    const dispatch = useDispatch();
    const clearId = () => {
        dispatch(changeBrandId2(null));
        dispatch(changeCategoryId(null));
        dispatch(changeAllProductId(null))
    }
    return (
        <>
            <NavLink to='/newProduct' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon> <AddCircleOutlineIcon/></ListItemIcon>
                        <ListItemText primary="Add product"/>
                    </ListItemButton>
                </List>
            </NavLink>
            <NavLink to='/editProduct' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon> <EditIcon/></ListItemIcon>
                        <ListItemText primary="Product list"/>
                    </ListItemButton>
                </List>
            </NavLink>
        </>
    );
}