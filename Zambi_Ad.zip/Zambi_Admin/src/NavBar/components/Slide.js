import * as React from "react";
import {List, ListItemButton, ListItemIcon, ListItemText} from "@mui/material";
import {NavLink} from "react-router-dom";
import {changeSlideId} from "../../Redux/getSlides/slice";
import {useDispatch} from "react-redux";
import {AddCircleOutlineIcon, EditIcon} from "../../icons/Icons";

export function Slide() {
    const dispatch = useDispatch();
    const clearId = () => {
        dispatch(changeSlideId(null))
    }
    return (
        <>
            <NavLink to='/newSlide' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><AddCircleOutlineIcon/></ListItemIcon>
                        <ListItemText primary="New slide"/>
                    </ListItemButton>
                </List>
            </NavLink>
            <NavLink to='/editSlide' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><EditIcon/></ListItemIcon>
                        <ListItemText primary="Slide list"/>
                    </ListItemButton>
                </List>
            </NavLink>
        </>
    );
}