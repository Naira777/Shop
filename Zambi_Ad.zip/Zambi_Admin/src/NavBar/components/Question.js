import * as React from "react";
import {NavLink} from "react-router-dom";
import {useDispatch} from "react-redux";
import {changeRecipeId} from "../../Redux/getRecipe/slice";
import {AddCircleOutlineIcon, EditIcon} from "../../icons/Icons";
import {List, ListItemButton, ListItemIcon, ListItemText} from "@mui/material";
import {changeQuestionId} from "../../Redux/getQuestion/slice";

export function Question() {
    const dispatch = useDispatch();
    const clearId = () => {
        dispatch(changeQuestionId(null))
        dispatch(changeRecipeId(null))
    }
    return (
        <>
            <NavLink to='/newQuestion' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><AddCircleOutlineIcon/></ListItemIcon>
                        <ListItemText primary="New Question"/>
                    </ListItemButton>
                </List>
            </NavLink>
            <NavLink to='/editQuestion' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><EditIcon/></ListItemIcon>
                        <ListItemText primary="Question list"/>
                    </ListItemButton>
                </List>
            </NavLink>
        </>
    );
}