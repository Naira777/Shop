import * as React from "react";
import {useDispatch} from "react-redux";
import {NavLink} from "react-router-dom";
import {List, ListItemButton, ListItemIcon, ListItemText} from "@mui/material";
import {AddCircleOutlineIcon, AllInboxIcon, EditIcon} from "../../icons/Icons";
import {changeAllAnnouncementId} from "../../Redux/getAnnouncement/slice";

export function Announcement() {
    const dispatch = useDispatch();
    const clearId = () => {
        dispatch(changeAllAnnouncementId(null))
    }
    return (
        <>
            <NavLink to='/newAnnouncement' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><AddCircleOutlineIcon/></ListItemIcon>
                        <ListItemText primary="New announcement"/>
                    </ListItemButton>
                </List>
            </NavLink>
            <NavLink to='/editAnnouncement' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><EditIcon/></ListItemIcon>
                        <ListItemText primary="Announcement list"/>
                    </ListItemButton>
                </List>
            </NavLink>
            <NavLink to='/allApply' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><AllInboxIcon/></ListItemIcon>
                        <ListItemText primary="All apply"/>
                    </ListItemButton>
                </List>
            </NavLink>
        </>
    );
}