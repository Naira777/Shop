import * as React from "react";
import {NavLink} from "react-router-dom";
import {useDispatch} from "react-redux";
import {changeRecipeId} from "../../Redux/getRecipe/slice";
import {AddCircleOutlineIcon, EditIcon} from "../../icons/Icons";
import {List, ListItemButton, ListItemIcon, ListItemText} from "@mui/material";

export function Recipe() {
    const dispatch = useDispatch();
    const clearId = () => {
        dispatch(changeRecipeId(null))
    }
    return (
        <>
            <NavLink to='/newRecipe'>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><AddCircleOutlineIcon/></ListItemIcon>
                        <ListItemText primary="New recipe"/>
                    </ListItemButton>
                </List>
            </NavLink>
            <NavLink to='/editRecipe' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><EditIcon/></ListItemIcon>
                        <ListItemText primary="Recipe list"/>
                    </ListItemButton>
                </List>
            </NavLink>
        </>
    );
}