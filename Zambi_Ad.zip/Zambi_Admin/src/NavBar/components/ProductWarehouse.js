import * as React from "react";
import {useDispatch} from "react-redux";
import {Link, NavLink} from "react-router-dom";
import {ListItemButton, ListItemIcon, ListItemText, Collapse, List} from "@mui/material";
import { AddCircleOutlineIcon, EditIcon, WarehouseTwoToneIcon} from '../../icons/Icons';
import {changeWarehouseId} from "../../Redux/getWarehouse/slice";
import {useState} from "react";
import {changeCategoryId} from "../../Redux/getCategory/slice";
import {changeAllProductId} from "../../Redux/getAllProduct/slice";
import {changeBrandId2} from "../../Redux/getBrand/slice";
import {changeProductId} from "../../Redux/getProduct/slice";

export function ProductWarehouse() {
    const [open,setOpen] =useState(false)
    const dispatch = useDispatch();
    const clearId = () => {
        dispatch(changeWarehouseId(null))
        dispatch(changeCategoryId(null))
        dispatch(changeAllProductId(null))
        dispatch(changeBrandId2(null))
        dispatch(changeProductId(null))
    }

    return (
        <>
            <ListItemButton className='title' sx={{pl: 3}} onClick={() => setOpen(!open)}>
                <ListItemIcon><WarehouseTwoToneIcon/></ListItemIcon>
                <ListItemText primary="Product warehouse"/>
            </ListItemButton>
            <Collapse in={open} timeout="auto" unmountOnExit>
                <NavLink to='/newProductWarehouse' onClick={clearId}>
                    <List component="div" disablePadding>
                        <ListItemButton sx={{pl: 4}}>
                            <ListItemIcon><AddCircleOutlineIcon/></ListItemIcon>
                            <ListItemText primary="New PW"/>
                        </ListItemButton>
                    </List>
                </NavLink>
                <NavLink to='/editProductWarehouse' onClick={clearId}>
                    <List component="div" disablePadding>
                        <ListItemButton sx={{pl: 4}}>
                            <ListItemIcon><EditIcon/></ListItemIcon>
                            <ListItemText primary="PW list"/>
                        </ListItemButton>
                    </List>
                </NavLink>
            </Collapse>
        </>
    );
}