import * as React from "react";
import {ListItemButton, ListItemIcon, ListItemText} from "@mui/material";
import {DeleteIcon, EditIcon} from '../../icons/Icons';
import {NavLink} from "react-router-dom";
import {changePrivacyEdit, changePrivacyId} from "../../Redux/getPrivacy/slice";
import {useDispatch} from "react-redux";
import List from "@mui/material/List";

export function Privacy() {
    const dispatch = useDispatch();
    const clearId = () => {
        dispatch(changePrivacyId(null))
        dispatch(changePrivacyEdit(null))
    }
    return (
        <>
            <NavLink to='/editPrivacy' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><EditIcon/></ListItemIcon>
                        <ListItemText primary="Update privacy"/>
                    </ListItemButton>
                </List>
            </NavLink>
            <NavLink to='/deletePrivacy' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><DeleteIcon/></ListItemIcon>
                        <ListItemText primary="Delete privacy translation"/>
                    </ListItemButton>
                </List>
            </NavLink>
        </>
    );
}