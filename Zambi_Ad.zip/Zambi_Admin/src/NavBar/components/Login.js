import * as React from "react";
import {NavLink, useNavigate} from "react-router-dom";
import {ListItemButton, ListItemIcon, ListItemText} from "@mui/material";
import {LoginIcon} from "../../icons/Icons";
import {useDispatch, useSelector} from "react-redux";
import {updateAdmin} from "../../Redux/getAdmin/slice";

export function Login() {
    const {isAdmin} = useSelector(state => state.admin)
    const dispatch = useDispatch();
    const navigate = useNavigate();
    return (
        <NavLink to='/login' onClick={(e) => {

            if (isAdmin) {
                e.preventDefault()
                const logout = window.confirm('Logout?')
                if (logout) {
                    navigate('/login')
                    localStorage.removeItem('admin')
                    dispatch(updateAdmin(null))
                }
            }
        }}>
            <ListItemButton className='title'>
                <ListItemIcon><LoginIcon/></ListItemIcon>
                <ListItemText primary={!isAdmin ? 'LOGIN' : 'LOGOUT'}/>
            </ListItemButton>
        </NavLink>
    );
};