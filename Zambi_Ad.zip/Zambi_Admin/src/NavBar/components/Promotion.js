import * as React from 'react';
import {List, ListItemButton, ListItemIcon, ListItemText} from "@mui/material";
import {NavLink} from "react-router-dom";
import {changeBrandId} from "../../Redux/getCategory/slice";
import {useDispatch} from "react-redux";
import {changePromotionId} from "../../Redux/getPromotion/slice";
import {AddCircleOutlineIcon, EditIcon} from "../../icons/Icons";

export function Promotion() {
    const dispatch = useDispatch();
    const clearId = () => {
        dispatch(changePromotionId(null))
        dispatch(changeBrandId(null))
    }
    return (
        <>
            <NavLink to='/newPromotion' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><AddCircleOutlineIcon/></ListItemIcon>
                        <ListItemText primary="New promotion"/>
                    </ListItemButton>
                </List>
            </NavLink>
            <NavLink to='/editPromotion' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><EditIcon/></ListItemIcon>
                        <ListItemText primary="Promotion list"/>
                    </ListItemButton>
                </List>
            </NavLink>
        </>
    );
};