import * as React from "react";
import {useDispatch} from "react-redux";
import {NavLink} from "react-router-dom";
import {changeBrandId, changeCategoryId} from "../../Redux/getCategory/slice";
import {List, ListItemButton, ListItemIcon, ListItemText} from "@mui/material";
import {AddCircleOutlineIcon, EditIcon} from "../../icons/Icons";
import {changeBrandId2} from "../../Redux/getBrand/slice";
import {changeAllProductId} from "../../Redux/getAllProduct/slice";

export function Brand() {
    const dispatch = useDispatch();
    const clearId = () => {
        dispatch(changeBrandId(null))
        dispatch(changeBrandId2(null));
        dispatch(changeCategoryId(null));
        dispatch(changeAllProductId(null))
    }

    return (
        <>
            <NavLink to='/newBrand' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><AddCircleOutlineIcon/></ListItemIcon>
                        <ListItemText primary="New brand"/>
                    </ListItemButton>
                </List>
            </NavLink>
            <NavLink to='/editBrand' onClick={clearId}>
                <List component="div" disablePadding>
                    <ListItemButton sx={{pl: 4}}>
                        <ListItemIcon><EditIcon/></ListItemIcon>
                        <ListItemText primary="Brand list"/>
                    </ListItemButton>
                </List>
            </NavLink>
        </>
    );
}