import * as React from 'react';
import {
    AnnouncementIcon,
    DeliveryDiningIcon,
    DiscountIcon,
    EmailIcon,
    FiberNewIcon,
    FoodBankIcon,
    LocalMallIcon,
    LocalShippingIcon,
    PersonOffIcon,
    PhotoSizeSelectActualIcon,
    PriceChangeIcon,
    PrivacyTipIcon,
    QuestionMarkSharpIcon,
    StarsOutlinedIcon,
    WarehouseIcon
} from "../icons/Icons";
import {Product} from "./components/Product";
import {Brand} from "./components/Brand";
import {Promotion} from "./components/Promotion";
import {Recipe} from "./components/Recipe";
import {Slide} from "./components/Slide";
import {Warehouse} from "./components/Warehouse";
import {Privacy} from "./components/Privacy";
import {Announcement} from "./components/Announcement";
import {CoWorker} from "./components/CoWorker";
import {Question} from "./components/Question";

export const NavBarList = () => [
    {
        id: 1,
        icon: <LocalMallIcon/>,
        title: "Product",
        component: <Product/>
    },
    {
        id: 2,
        icon: <FiberNewIcon/>,
        title: "Brand",
        component: <Brand/>
    },
    {
        id: 3,
        icon: <DiscountIcon/>,
        title: "Promotion",
        component: <Promotion/>
    },
    {
        id: 4,
        icon: <FoodBankIcon/>,
        title: "Recipe",
        component: <Recipe/>
    },
    {
        id: 5,
        icon: <PhotoSizeSelectActualIcon/>,
        title: "Slide",
        component: <Slide/>
    },
    {
        id: 6,
        icon: <WarehouseIcon/>,
        title: "Warehouse",
        component: <Warehouse/>
    },
    {
        id: 7,
        icon: <PrivacyTipIcon/>,
        title: "Privacy",
        component: <Privacy/>
    },
    {
        id: 8,
        link: '/Permissions',
        icon: <StarsOutlinedIcon/>,
        title: "Permissions",
    },
    {
        id: 9,
        icon: <QuestionMarkSharpIcon/>,
        title: "Question",
        component: <Question/>
    },
    {
        id: 10,
        icon: <AnnouncementIcon/>,
        title: "Announcement",
        component: <Announcement/>
    },
    {
        id: 11,
        icon: <DeliveryDiningIcon/>,
        title: "CoWorker",
        component: <CoWorker/>
    },
    {
        id: 12,
        link: '/provider',
        icon: <LocalShippingIcon/>,
        title: "Provider",
    },
    {
        id: 13,
        link: '/email',
        icon: <EmailIcon/>,
        title: "Email",
    },
    {
        id: 14,
        link: '/users',
        icon: <PersonOffIcon/>,
        title: "Users",
    },
    {
        id: 15,
        link: 'deliverPrice',
        icon: <PriceChangeIcon/>,
        title: "DeliverPrice",
    },
]
