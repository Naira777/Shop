import img1 from '../img/loading.gif'
import img2 from '../img/reject.png'

export function loading(on) {
    document.getElementById('loading-gif').style.background = `url(${img1}) no-repeat center/contain`
    document.getElementById('loading').style.display = `${on ? 'block' : 'none'}`
}

export function reject() {
    document.getElementById('loading-gif').style.background = `url(${img2}) no-repeat center/contain`
    document.getElementById('loading').style.display = 'block'
    const t = setTimeout(() => {
        document.getElementById('loading').style.display = 'none'
        clearTimeout(t)
    }, 800)
}
