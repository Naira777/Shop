import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const privacySlice = createSlice({
    name: 'data',
    initialState: {
        privacy_data: [],
        privacy_id: null,
        privacyEdit: null,
    },
    reducers: {
        changePrivacyId: (state, action) => {
            state.privacy_id = action.payload;
        },
        changePrivacyEdit: (state, action) => {
            state.privacyEdit = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getPrivacy.fulfilled, (state, action) => {
                state.privacy_data = action.payload.data.data;
            })
    },
})

export default privacySlice;

export const {changePrivacyId, changePrivacyEdit} = privacySlice.actions;