import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const warehouseSlice = createSlice({
    name: 'data',
    initialState: {
        warehouse_data: [],
        one_warehouse_data: [],
        warehouse_id: null
    },
    reducers: {
        changeWarehouseId: (state, action) => {
            state.warehouse_id = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getWarehouse.fulfilled, (state, action) => {
                state.warehouse_data = action.payload.data.data;
            })
            .addCase(API.getOneWarehouse.fulfilled, (state, action) => {
                state.one_warehouse_data = action.payload.data.data;
            })
    },
})

export default warehouseSlice;

export const {changeWarehouseId} = warehouseSlice.actions;