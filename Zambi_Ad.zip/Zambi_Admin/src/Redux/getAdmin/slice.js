import {createSlice} from "@reduxjs/toolkit";

const adminSlice = createSlice({
    name: 'data',
    initialState: {isAdmin: false},
    reducers: {
        updateAdmin: (state, action) => {
            state.isAdmin = action.payload;
        },
    },
})

export default adminSlice;

export const {updateAdmin} = adminSlice.actions;