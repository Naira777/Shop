import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const coWorkerSlice = createSlice({
    name: 'data',
    initialState: {
        co_worker_data: [],
        one_co_worker_data: [],
        co_worker_id: null,
    },
    reducers: {
        changeCoWorkerId: (state, action) => {
            state.co_worker_id = action.payload;
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getCoWorker.fulfilled, (state, action) => {
                state.co_worker_data = action.payload.data.data;
            })
            .addCase(API.getOneCoWorker.fulfilled, (state, action) => {
                state.one_co_worker_data = action.payload.data.data;
            })
    },
})

export default coWorkerSlice;

export const {changeCoWorkerId} = coWorkerSlice.actions;