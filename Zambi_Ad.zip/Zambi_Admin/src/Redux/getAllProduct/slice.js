import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const allProductSlice = createSlice({
    name: 'data',
    initialState: {
        allProduct_data: [],
        allProduct_id: null
    },
    reducers: {
        changeAllProductId: (state, action) => {
            state.allProduct_id = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getAllProduct.pending, () => {
                document.getElementById('loading').style.display = 'block'
            })
            .addCase(API.getAllProduct.fulfilled, (state, action) => {
                state.allProduct_data = action.payload.data.data;
                document.getElementById('loading').style.display = 'none'
            })
    },
})

export default allProductSlice;

export const {changeAllProductId} = allProductSlice.actions;