import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";
import './style.scss';

const PermissionSlice = createSlice({
    name: 'data',
    initialState: {
        permission_data: [],
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getPermission.fulfilled, (state, action) => {
                state.permission_data = action.payload.data.data;
            })
    },
})

export default PermissionSlice;
