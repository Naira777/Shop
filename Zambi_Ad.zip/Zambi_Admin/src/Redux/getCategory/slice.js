import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const ProductCategorySlice = createSlice({
    name: 'data',
    initialState: {
        error: null,
        category_data: [],
        category_data_child: [],
        category_id: null,
        category_id2: null
    },
    reducers: {
        changeBrandId: (state, action) => {
            state.category_id = action.payload;
        },
        changeCategoryId: (state, action) => {
            state.category_id2 = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getProductCategory.fulfilled, (state, action) => {
                state.category_data = action.payload.data.data;
            })
            .addCase(API.getCategoryChild.fulfilled, (state, action) => {
                state.category_data_child = action.payload.data.data;
            })
    },
})

export default ProductCategorySlice;

export const {changeBrandId, changeCategoryId} = ProductCategorySlice.actions;