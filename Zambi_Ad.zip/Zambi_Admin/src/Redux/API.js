import axiosGet from "../helpers/axios/axiosGet";
import {createAsyncThunk} from "@reduxjs/toolkit";
import axiosGetP from "../helpers/axios/axiosPost";
import axios from "axios";

const header = {headers: {"Authorization": `Bearer ${localStorage.getItem('admin')}`}}

export const API = Object.freeze({
    uploadImage: (image) => axios.post(`${process.env.REACT_APP_BASE_URL}api/image-upload`, image, {headers: {'Content-Type': 'multipart/form-data'}}),
    updateImage: (data) => axios.post(`${process.env.REACT_APP_BASE_URL}api/image-update`, data, {headers: {'Content-Type': 'multipart/form-data'}}),

    getProduct: createAsyncThunk(
        'get/products',
        async (params) => await axiosGet.get(`api/product?filter_by_is_express=all&filter_by_product_type=all&filter_by_main_filter=all&category=${params}`)
    ),
    getOneProduct: createAsyncThunk(
        'post/oneProduct',
        async (id) => await axiosGet.get(`api/product/${id}?filter_by_delivery_type=supermarket`)
    ),
    getCategoryChild: createAsyncThunk(
        'get/categoryChild',
        async (params) => await axiosGet.get(`api/product/category/categoryTree/${params}`)
    ),
    getAllProductByCategory: createAsyncThunk(
        'get/allProducts',
        async (params) => await axiosGet.get(`api/product?category=${params}&filter_by_is_express=all&filter_by_product_type=all&filter_by_main_filter=all`)
    ),
    getAllProduct: createAsyncThunk(
        'get/allProducts',
        async () => await axiosGet.get(`api/product?filter_by_is_express=all&filter_by_product_type=all&filter_by_main_filter=all&category=all`)
    ),
    getNextProduct: createAsyncThunk(
        'get/nextProducts',
        async (params) => await axiosGet.get(`${params.links.next}&category=${params.data[0].category_id}&filter_by_is_express=all&filter_by_main_filter=all&filter_by_product_type=all`)
    ),
    getDiscount: createAsyncThunk(
        'get/discountProducts',
        async (params) => await axiosGet.get(`api/discounted-product?category=${params}&filter_by_is_express=all&filter_by_main_filter=all&filter_by_product_type=all`)
    ),
    getBrandList: createAsyncThunk(
        'get/brandList',
        async () => await axiosGet.get(`api/brand`)
    ),
    getBrandListByCategory: createAsyncThunk(
        'get/brandListByCategory',
        async (id) => await axiosGet.get(`api/brand/category/${id}`)
    ),
    getBrandByCategory: createAsyncThunk(
        'get/BrandByCategory',
        async (params) => await axiosGet.get(`api/brand/category/${params}`)
    ),
    getOneBrand: createAsyncThunk(
        'get/oneBrand',
        async (params) => await axiosGet.get(`api/brand/${params}?filter_by_is_express=all&filter_by_main_filter=all`)
    ),
    getProductCategory: createAsyncThunk(
        'get/category',
        async () => await axiosGet.get('api/product/category/list')
    ),
    getPromotion: createAsyncThunk(
        'get/promotions',
        async () => await axiosGet.get('api/promotion')
    ),
    getOnePromotion: createAsyncThunk(
        'get/onePromotion',
        async (params) => await axiosGet.get(`api/promotion/${params}?filter_by_status=not_read`)
    ),
    getSlide: createAsyncThunk(
        'get/slide',
        async () => await axiosGet.get('api/slide/show')
    ),
    getOneSlide: createAsyncThunk(
        'get/oneSlide',
        async (params) => await axiosGet.get(`api/slide/${params}`)
    ),
    getAllRecipe: createAsyncThunk(
        'get/recipe',
        async () => await axiosGet.get('api/recipe')
    ),
    getOneRecipe: createAsyncThunk(
        'get/oneRecipe',
        async (params) => await axiosGet.get(`api/recipe/${params}`)
    ),
    getWarehouse: createAsyncThunk(
        'get/warehouse',
        async () => await axiosGet.get('api/warehouse?filter_by_is_active=all')
    ),
    getOneWarehouse: createAsyncThunk(
        'get/oneWarehouse',
        async (params) => await axiosGet.get(`api/warehouse/${params}?filter_by_is_active=all`)
    ),
    getPrivacy: createAsyncThunk(
        'get/privacy',
        async () => await axiosGet.get('api/privacy')
    ),
    getPermission: createAsyncThunk(
        'get/permission',
        async () => await axiosGet.get('admin-api/permission', header)
    ),
    getQuestion: createAsyncThunk(
        'get/question',
        async () => await axiosGet.get('api/question')
    ),
    getOneQuestion: createAsyncThunk(
        'get/oneQuestion',
        async (params) => await axiosGet.get(`api/question/${params}`)
    ),
    getAnnouncement: createAsyncThunk(
        'get/announcement',
        async () => await axiosGet.get('api/announcement')
    ),
    getOneAnnouncement: createAsyncThunk(
        'get/oneAnnouncement',
        async (params) => await axiosGet.get(`api/announcement/${params}`)
    ),
    getApply: createAsyncThunk(
        'get/apply',
        async () => await axiosGet.get(`admin-api/apply`, header)
    ),
    getWorkCategory: createAsyncThunk(
        'get/workCategory',
        async () => await axiosGet.get('api/work-category')
    ),
    getWorkingHours: createAsyncThunk(
        'get/workHours',
        async () => await axiosGet.get('api/working-hours')
    ),
    getCoWorker: createAsyncThunk(
        'get/coWorker',
        async () => await axiosGet.get('api/co_worker')
    ),
    getOneCoWorker: createAsyncThunk(
        'get/oneCoWorker',
        async (params) => await axiosGet.get(`api/co_worker/${params}`)
    ),
    getProvider: createAsyncThunk(
        'get/provider',
        async () => await axiosGet.get('admin-api/provider', header)
    ),
    getEmail: createAsyncThunk(
        'get/email',
        async () => await axiosGet.get('admin-api/send-email?filter_by_type=all', header)
    ),
    getUser: createAsyncThunk(
        'get/user',
        async () => await axiosGet.get('api/user')
    ),
    getDeliver: createAsyncThunk(
        'get/deliver',
        async () => await axiosGet.get('api/delivery-type')
    ),
    postProductData: createAsyncThunk(
        'post/data',
        async (data) => await axiosGetP.post('admin-api/product', data)
    ),
    updateData: createAsyncThunk(
        'post/updateData',
        async (data) => await axiosGetP.post(`admin-api/product/${data.id}`, data)
    ),
    postBrandData: createAsyncThunk(
        'post/brandData',
        async (data) => await axiosGetP.post('admin-api/product', data)
    ),
    updateBrandData: createAsyncThunk(
        'post/updateData',
        async (data) => await axiosGetP.post(`admin-api/product/${data.brand_id}`, data)
    ),
})