import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const questionSlice = createSlice({
    name: 'data',
    initialState: {
        question_data: [],
        one_question_data: [],
        question_id: null
    },
    reducers: {
        changeQuestionId: (state, action) => {
            state.question_id = action.payload;
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getQuestion.fulfilled, (state, action) => {
                state.question_data = action.payload.data.data;
            })
            .addCase(API.getOneQuestion.fulfilled, (state, action) => {
                state.one_question_data = action.payload.data.data;
            })
    },
})

export default questionSlice;

export const {changeQuestionId} = questionSlice.actions;