import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const SlideSlice = createSlice({
    name: 'data',
    initialState: {
        slide_data: [],
        one_slide_data: [],
        slide_id: null
    },
    reducers: {
        changeSlideId: (state, action) => {
            state.slide_id = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getSlide.fulfilled, (state, action) => {
                state.slide_data = action.payload.data.data;
            })
            .addCase(API.getOneSlide.fulfilled, (state, action) => {
                state.one_slide_data = action.payload.data.data;
            })
    },
})

export default SlideSlice;

export const {changeSlideId} = SlideSlice.actions;