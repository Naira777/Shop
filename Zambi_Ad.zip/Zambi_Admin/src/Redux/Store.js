import {configureStore} from "@reduxjs/toolkit";
import ProductCategorySlice from "./getCategory/slice";
import promotionSlice from "./getPromotion/slice";
import productSlice from "./getProduct/slice";
import SlideSlice from "./getSlides/slice";
import recipeSlice from "./getRecipe/slice";
import brandSlice from "./getBrand/slice";
import warehouseSlice from "./getWarehouse/slice";
import allProductSlice from "./getAllProduct/slice";
import privacySlice from "./getPrivacy/slice";
import PermissionSlice from "./getPermission/slice";
import questionSlice from "./getQuestion/slice";
import workCategoryHoursSlice from "./getWorkCategoryHours/slice";
import coWorkerSlice from "./getCoWorker/slice";
import providerSlice from "./getProvider/slice";
import emailSlice from "./getEmail/slice";
import adminSlice from "./getAdmin/slice";
import userSlice from "./getUser/slice";
import deliverSlice from "./getDeliver/slice";
import announcementSlice from "./getAnnouncement/slice";

export const store = configureStore({
    reducer: {
        slide: SlideSlice.reducer,
        productCategory: ProductCategorySlice.reducer,
        promotion: promotionSlice.reducer,
        product: productSlice.reducer,
        allProduct: allProductSlice.reducer,
        brand: brandSlice.reducer,
        recipe: recipeSlice.reducer,
        warehouse: warehouseSlice.reducer,
        privacy: privacySlice.reducer,
        permission: PermissionSlice.reducer,
        question: questionSlice.reducer,
        workCategoryHours: workCategoryHoursSlice.reducer,
        coWorker: coWorkerSlice.reducer,
        provider: providerSlice.reducer,
        email: emailSlice.reducer,
        admin: adminSlice.reducer,
        user: userSlice.reducer,
        deliver: deliverSlice.reducer,
        announcement: announcementSlice.reducer,
    },
    middleware: (getDefaultMiddleware) => getDefaultMiddleware({serializableCheck: false}),
    devTools: process.env.REACT_APP_ENV !== 'dev',
});
