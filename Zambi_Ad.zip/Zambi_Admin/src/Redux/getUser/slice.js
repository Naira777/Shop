import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const userSlice = createSlice({
    name: 'data',
    initialState: {
        user_data: [],
        user_id: null
    },
    reducers: {
        changeUserId: (state, action) => {
            state.user_id = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getUser.fulfilled, (state, action) => {
                state.user_data = action.payload.data.data;
            })
    },
})

export default userSlice;

export const {changeUserId} = userSlice.actions;