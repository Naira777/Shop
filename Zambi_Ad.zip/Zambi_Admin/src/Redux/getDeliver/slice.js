import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const deliverSlice = createSlice({
    name: 'data',
    initialState: {
        deliver_data: [],
        deliver_id: null,
    },
    reducers: {
        changeDeliverId: (state, action) => {
            state.deliver_id = action.payload;
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getDeliver.fulfilled, (state, action) => {
                state.deliver_data = action.payload.data.data;
            })
    },
})

export default deliverSlice;

export const {changeDeliverId} = deliverSlice.actions;