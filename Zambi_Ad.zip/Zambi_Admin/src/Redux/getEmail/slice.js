import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const emailSlice = createSlice({
    name: 'data',
    initialState: {
        email_data: null,
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getEmail.fulfilled, (state, action) => {
                state.email_data = action.payload.data.data;
            })
    },
})

export default emailSlice;
