import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const announcementSlice = createSlice({
    name: 'data',
    initialState: {
        apply_data: [],
        all_announcement_data: [],
        one_announcement_data: [],
        all_announcement_id: null
    },
    reducers: {
        changeAllAnnouncementId: (state, action) => {
            state.all_announcement_id = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getAnnouncement.fulfilled, (state, action) => {
                state.all_announcement_data = action.payload.data.data;
            })
            .addCase(API.getOneAnnouncement.fulfilled, (state, action) => {
                state.one_announcement_data = action.payload.data.data;
            })
            .addCase(API.getApply.fulfilled, (state, action) => {
                state.apply_data = action.payload.data.data;
            })
    },
})

export default announcementSlice;

export const {changeAllAnnouncementId} = announcementSlice.actions;