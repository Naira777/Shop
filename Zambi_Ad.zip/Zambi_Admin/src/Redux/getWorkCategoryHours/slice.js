import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const workCategoryHoursSlice = createSlice({
    name: 'data',
    initialState: {
        work_category: [],
        work_category_hours: [],
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getWorkCategory.fulfilled, (state, action) => {
                state.work_category = action.payload.data.data;
            })
            .addCase(API.getWorkingHours.fulfilled, (state, action) => {
                state.work_category_hours = action.payload.data.data;
            })
    },
})

export default workCategoryHoursSlice;
