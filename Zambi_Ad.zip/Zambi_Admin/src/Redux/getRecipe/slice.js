import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const recipeSlice = createSlice({
    name: 'data',
    initialState: {
        all_recipe_data: [],
        one_recipe: [],
        recipe_id: null,
    },
    reducers: {
        changeRecipeId: (state, action) => {
            state.recipe_id = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getAllRecipe.fulfilled, (state, action) => {
                state.all_recipe_data = action.payload.data.data;
            })
            .addCase(API.getOneRecipe.fulfilled, (state, action) => {
                state.one_recipe = action.payload.data.data;
            })
    },
})

export default recipeSlice;

export const {changeRecipeId} = recipeSlice.actions;