import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const brandSlice = createSlice({
    name: 'data',
    initialState: {
        brand_data: [],
        brand_list: [],
        brand_list_by_category: [],
        one_brand: {},
        brand_id: null
    },
    reducers: {
        changeBrandId2: (state, action) => {
            state.brand_id = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getBrandByCategory.fulfilled, (state, action) => {
                state.brand_data = action.payload.data.data;
            })
            .addCase(API.getOneBrand.fulfilled, (state, action) => {
                state.one_brand = action.payload.data.data;
            })
            .addCase(API.getBrandList.fulfilled, (state, action) => {
                state.brand_list = action.payload.data.data;
            })
            .addCase(API.getBrandListByCategory.fulfilled, (state, action) => {
                state.brand_list_by_category = action.payload.data.data;
            })
    },
})

export default brandSlice;

export const {changeBrandId2} = brandSlice.actions;