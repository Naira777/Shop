import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const providerSlice = createSlice({
    name: 'data',
    initialState: {
        provider_data: [],
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getProvider.fulfilled, (state, action) => {
                state.provider_data = action.payload.data.data;
            })
    },
})

export default providerSlice;
