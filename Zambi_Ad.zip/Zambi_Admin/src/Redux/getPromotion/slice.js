import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const promotionSlice = createSlice({
    name: 'data',
    initialState: {
        promotion_data: [],
        one_promotion_data: [],
        promotion_id: null
    },
    reducers: {
        changePromotionId: (state, action) => {
            state.promotion_id = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getPromotion.fulfilled, (state, action) => {
                state.promotion_data = action.payload.data.data;
            })
            .addCase(API.getOnePromotion.fulfilled, (state, action) => {
                state.one_promotion_data = action.payload.data.data;
            })
    },
})

export default promotionSlice;

export const {changePromotionId} = promotionSlice.actions;