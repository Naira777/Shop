import {createSlice} from "@reduxjs/toolkit";
import {API} from "../API";

const productSlice = createSlice({
    name: 'data',
    initialState: {
        product_data: [],
        discount_product_data: [],
        all_product_data: [],
        one_product: {},
        product_id: null,
        discount_id: null,
        all_product_id: null
    },
    reducers: {
        changeProductId: (state, action) => {
            state.product_id = action.payload;
        },
        changeAllProductId: (state, action) => {
            state.all_product_id = action.payload;
        },
        changeDiscountId: (state, action) => {
            state.discount_id = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(API.getProduct.fulfilled, (state, action) => {
                state.product_data = action.payload.data.data;
            })
            .addCase(API.getAllProductByCategory.fulfilled, (state, action) => {
                state.all_product_data = action.payload.data;
            })
            .addCase(API.getNextProduct.fulfilled, (state, action) => {
                state.all_product_data.data = [...state.all_product_data.data, ...action.payload.data.data];
                state.all_product_data.links = [action.payload.data.links];
            })
            .addCase(API.getOneProduct.fulfilled, (state, action) => {
                state.one_product = action.payload.data.data;
            })
            .addCase(API.getDiscount.fulfilled, (state, action) => {
                state.discount_product_data = action.payload.data.data;
            })
    },
})

export default productSlice;

export const {changeProductId, changeAllProductId, changeDiscountId} = productSlice.actions;