import {NewSlide} from "../pages/slide/NewSlide";
import {SlideList} from "../pages/slide/SlideList";
import {EditPromotion} from "../pages/promotion/EditPromotion";
import {EditRecipe} from "../pages/recipe/EditRecipe";
import {NewWarehouse} from "../pages/warehouse/newWarehouse";
import {EditWarehouse} from "../pages/warehouse/EditWarehouse";
import {ProductWarehouseList} from "../pages/warehouse/productWarehouse/ProductWarehouseList";
import {EditProductWarehouse} from "../pages/warehouse/productWarehouse/EditProductWarehouse";
import {PrivacyList} from "../pages/privacy/PrivacyList";
import {DeletePrivacy} from "../pages/privacy/DeletePrivacy";
import {Permissions} from "../pages/permission/Permissions";
import {NewQuestion} from "../pages/question/NewQuestion";
import {EditQuestion} from "../pages/question/EditQuestion";
import {NewAnnouncement} from "../pages/announcement/NewAnnouncement";
import {NewCoWorkers} from "../pages/coWorkers/NewcoWorkers";
import {CoWorkerList} from "../pages/coWorkers/CoWorkerList";
import {Providers} from "../pages/provider/Providers";
import {Email} from "../pages/email/Email";
import {ProductList} from "../pages/product/ProductList";
import {EditProduct} from "../pages/product/EditProduct";
import {BrandListAdd} from "../pages/brand/BrandListAdd";
import {EditBrand} from "../pages/brand/EditBrand";
import {NewPromotion} from "../pages/promotion/NewPromotion";
import {UserList} from "../pages/users/UserList";
import {DeliverList} from "../pages/deliver/deliverList";
import {AnnouncementList} from "../pages/announcement/AnnouncementList";
import {ApplyList} from "../pages/announcement/ApplyList";
import {NewRecipe} from "../pages/recipe/NewRecipe";

export function MainRouts() {
    return [
        {
            path: '/',
            element: <UserList/>
        },
        {
            path: '/newSlide',
            element: <NewSlide/>
        },
        {
            path: '/editSlide',
            element: <SlideList/>
        },
        {
            path: '/newProduct',
            element: <ProductList/>
        },
        {
            path: '/editProduct',
            element: <EditProduct/>
        },
        {
            path: '/newBrand',
            element: <BrandListAdd/>
        },
        {
            path: '/editBrand',
            element: <EditBrand/>
        },
        {
            path: '/newPromotion',
            element: <NewPromotion/>
        },
        {
            path: '/editPromotion',
            element: <EditPromotion/>
        },
        {
            path: '/newRecipe',
            element: <NewRecipe/>
        },
        {
            path: '/editRecipe',
            element: <EditRecipe/>
        },
        {
            path: '/newWarehouse',
            element: <NewWarehouse/>
        },
        {
            path: '/editWarehouse',
            element: <EditWarehouse/>
        },
        {
            path: '/newProductWarehouse',
            element: <EditProductWarehouse/>
        },
        {
            path: '/editProductWarehouse',
            element: <ProductWarehouseList/>
        },
        {
            path: '/editPrivacy',
            element: <PrivacyList/>
        },
        {
            path: '/deletePrivacy',
            element: <DeletePrivacy/>
        },
        {
            path: '/Permissions',
            element: <Permissions/>
        },
        {
            path: '/newQuestion',
            element: <NewQuestion/>
        },
        {
            path: '/editQuestion',
            element: <EditQuestion/>
        },
        {
            path: '/newAnnouncement',
            element: <NewAnnouncement/>
        },
        {
            path: '/editAnnouncement',
            element: <AnnouncementList/>
        },
        {
            path: '/allApply',
            element: <ApplyList/>
        },
        {
            path: '/newCoWorker',
            element: <NewCoWorkers/>
        },
        {
            path: '/editCoWorker',
            element: <CoWorkerList/>
        },
        {
            path: '/provider',
            element: <Providers/>
        },
        {
            path: '/email',
            element: <Email/>
        },
        {
            path: '/users',
            element: <UserList/>
        },
        {
            path: '/deliverPrice',
            element: <DeliverList/>
        },
        {
            path: '*',
            element: <div className='error'></div>
        },
    ]
}
