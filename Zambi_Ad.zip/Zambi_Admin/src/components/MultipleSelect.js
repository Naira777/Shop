import React from 'react';
import Select from 'react-select';

export default function MultipleSelect({options, handleChange}) {
    const list = options?.map(v => ({
        value: v?.translation?.title,
        label: v?.translation?.title,
        code: v?.code,
        id: v.id
    }))
    return (
        <Select
            className='multi-select'
            isMulti
            options={list}
            onChange={handleChange}
            closeMenuOnSelect={false}
        />
    )
}
