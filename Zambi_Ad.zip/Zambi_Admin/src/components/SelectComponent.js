import {Field} from "formik";

export function SelectComponent({cls, name, b, options}) {
    const page1 = b === 'Brand: ';
    return (
        <span className={cls}>
            <b>{b}</b>
            <Field as="select" name={name}>
                {options?.map(item => {
                    return <option key={item.value || item.id} value={page1 ? item.id : item.value}>
                        {page1 ? item.translation.title : item.content}
                    </option>
                })}
            </Field>
        </span>
    );
}