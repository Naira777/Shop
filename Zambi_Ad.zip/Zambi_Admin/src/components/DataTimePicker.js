import {useState, React} from "react";
import {TextField, Stack} from "@mui/material";
import {AdapterDateFns} from '@mui/x-date-pickers/AdapterDateFns';
import {LocalizationProvider, DateTimePicker} from '@mui/x-date-pickers';

export default function DataTimePicker({func}) {
    const [value, setValue] = useState(new Date());

    const handleChange = (newValue) => setValue(newValue);
    return (
        <LocalizationProvider dateAdapter={AdapterDateFns}>
            <Stack spacing={3}>
                <DateTimePicker
                    label="Date&Time picker"
                    value={value}
                    inputFormat='yyyy-MM-dd/hh-mm-ss'
                    onChange={handleChange}
                    renderInput={(params) => {
                        func(params.inputProps.value)
                        return <TextField {...params}/>
                    }}
                />
            </Stack>
        </LocalizationProvider>
    );
}
