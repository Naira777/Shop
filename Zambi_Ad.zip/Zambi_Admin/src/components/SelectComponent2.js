import {Field} from "formik";

export function SelectComponent2({cls, name, b, options}) {
    return (
        <span className={cls}>
            <b>{b}</b>
            <Field as="select" name={name}>
                {options?.map((item, id) => {
                    return (
                        name === 'locality_code' ? <option key={id} value={item.code}>{item.translation.locality_name}</option>
                            : <option key={id} value={item.id}>{item.translation.title}</option>
                    )
                })}
            </Field>
        </span>
    );
}