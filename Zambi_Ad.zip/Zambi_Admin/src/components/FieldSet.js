import {TextField} from "@mui/material";
import Button from "@mui/material/Button";

export function FieldSetComponent(
    {
        name1,
        name2,
        name3,
        value1,
        value2,
        value3,
        label1,
        label2,
        label3,
        onChange,
        onChange2,
        onChange3,
        button,
        legend,
        cls = ""
    }) {
    return (
        legend ?
            <fieldset className={cls}>
                {legend && <legend>{legend}</legend>}
                <TextField
                    required
                    name={name1}
                    value={value1}
                    disabled={!onChange2}
                    onChange={onChange2}
                    label={label1}
                    variant="outlined"
                />
                {name2 && <TextField
                    required
                    name={name2}
                    onChange={onChange}
                    value={value2}
                    label={label2}
                    variant="outlined"
                />}
                {name3 && <TextField
                    required
                    name={name3}
                    onChange={onChange3}
                    value={value3}
                    label={label3}
                    variant="outlined"
                />}
                {button && (
                    <Button
                        variant='contained'
                        className='form-send'
                        type='submit'>
                        Login
                    </Button>
                )}
            </fieldset>
            :
            <div className='field'>
                <TextField
                    required
                    name={name1}
                    value={value1}
                    disabled={!onChange2}
                    onChange={onChange2}
                    label={label1}
                    variant="outlined"
                />
                {name2 && (
                    <TextField
                        required
                        name={name2}
                        onChange={onChange}
                        value={value2}
                        label={label2}
                        variant="outlined"
                    />
                )}
                {name3 && (
                    <TextField
                        required
                        name={name3}
                        onChange={onChange3}
                        value={value3}
                        label={label3}
                        variant="outlined"
                    />
                )}
                {button && (
                    <Button
                        variant='contained'
                        className='form-send'
                        type='submit'>
                        Login
                    </Button>
                )}
            </div>
    );
}