import {useDispatch, useSelector} from "react-redux";
import {NewAnnouncement} from "./NewAnnouncement";
import {API} from "../../Redux/API";
import {useEffect} from "react";
import Button from "@mui/material/Button";
import axios from "../../helpers/axios/axiosPost";
import {changeAllAnnouncementId} from "../../Redux/getAnnouncement/slice";

export function AnnouncementList() {
    const {all_announcement_data, all_announcement_id} = useSelector(state => state.announcement)
    const dispatch = useDispatch();
    const update = () => {
        dispatch(API.getAnnouncement());
        dispatch(changeAllAnnouncementId(null))
    }
    useEffect((id) => {
        dispatch(API.getAnnouncement());
    }, [dispatch])
    const deleteFunction = async (id) => {
        await axios.delete(`admin-api/announcement/${id}`)
            .then(update)
    }

    return (
        <>
            {!all_announcement_id && <div className='announcement-list'>
                <h1>Announcement</h1>
                {all_announcement_data?.map(item => (
                    <div key={item.id} className='announcement-item'>
                        <h5>Deadline: <b>{item.deadline}</b></h5>
                        <h5>Is active: <b>{item.is_active}</b></h5>
                        <h5>Locality code: <b>{item.locality_code}</b></h5>
                        <h5>Description: <b>{item.translation?.description}</b></h5>
                        <Button className='delete'
                                onClick={() => deleteFunction(item.id)}>
                            Delete
                        </Button>
                    </div>))}
            </div>}
            {all_announcement_id && <NewAnnouncement/>}
        </>
    );
}