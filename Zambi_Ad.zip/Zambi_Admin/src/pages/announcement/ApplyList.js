import {useDispatch, useSelector} from "react-redux";
import {API} from "../../Redux/API";
import {useEffect} from "react";
import {Button} from "@mui/material";
import axiosPost from "../../helpers/axios/axiosPost";

export function ApplyList() {
    const {apply_data} = useSelector(state => state.announcement)
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(API.getApply());
    }, [])
    const update = () => dispatch(API.getApply());
    const deleteFunction = (id) => axiosPost.delete(`admin-api/apply/${id}`).then(update)
    return (
        <>
            <div className='announcement-list'>
                <h1>Apply</h1>
                {apply_data?.map(item => (
                    <div key={item.id} className='announcement-item'>
                        <h5>First name: <b>{item.first_name}</b></h5>
                        <h5>Last name: <b>{item.last_name}</b></h5>
                        <h5>Phone number: <b>{item.phone_number}</b></h5>
                        <h5>Work category: <b>{item.workCategory?.translation?.title}</b></h5>
                        <Button variant="contained"
                                onClick={() => deleteFunction(item.id)}>
                            Delete
                        </Button>
                    </div>))}
            </div>
        </>
    )
}