import Button from "@mui/material/Button";
import {FormikProvider, useFormik} from "formik";
import {useDispatch, useSelector} from "react-redux";
import axios from "../../helpers/axios/axiosPost";
import {FieldSetComponent} from "../../components/FieldSet";
import {SelectComponent} from "../../components/SelectComponent";
import CheckboxComponent from "../../components/MultipleSelect";
import {useEffect, useRef, useState} from "react";
import {SelectComponent2} from "../../components/SelectComponent2";
import DataTimePicker from "../../components/DataTimePicker";
import {API} from "../../Redux/API";
import {changeAllAnnouncementId} from "../../Redux/getAnnouncement/slice";
import {useNavigate} from "react-router-dom";
import {loading, reject} from "../../helpers/loading";

export function NewAnnouncement() {
    const dispatch = useDispatch()
    const {work_category, work_category_hours} = useSelector(state => state.workCategoryHours)
    const [requirements, setRequirements] = useState(null);
    const [locality, setLocality] = useState(null);
    const navigate = useNavigate()
    const b = useRef();
    const update = () => {
        dispatch(API.getAnnouncement());
        dispatch(changeAllAnnouncementId(null))
    }
    const postFunction = (data) => {
        loading(true)
        axios.post('admin-api/announcement', data)
            .then(_ => {
                update();
                navigate('/editAnnouncement')
                loading(false)
            })
            .catch(reject)
    }

    const formik = useFormik({
        initialValues: {
            translations: [
                {
                    lang_code: 'am',
                    description: '',
                },
                {
                    lang_code: 'ru',
                    description: '',
                },
                {
                    lang_code: 'en',
                    description: '',
                }
            ],
            locality_code: '',
            work_category_id: '1',
            working_hours_id: '1',
            deadline: '',
            is_active: 'yes',
            requirements: ''
        },
        onSubmit: () => postFunction(formik.values)
    })
    useEffect(() => {
        dispatch(API.getWorkCategory());
        dispatch(API.getWorkingHours());
        axios.get('api/requirement').then(data => setRequirements(data.data.data));
        axios.get('api/city').then(data => {
            setLocality(data.data.data)
            formik.setFieldValue('locality_code', data.data.data[0].code)
        });
    }, [dispatch])

    return (

        <div className='form-div'>
            <form className='new-announcement-form' onSubmit={formik.handleSubmit}>
                <div className='main'>
                    <FormikProvider value={formik}>
                        <div className='box warehouse'>
                            <legend>Translations</legend>
                            <FieldSetComponent
                                name1={'translations[0][description]'}
                                value1={formik.values?.translations?.[0]['description']}
                                label1={'AM Description'}
                                onChange2={formik.handleChange}
                            />
                            <FieldSetComponent
                                name1={'translations[1][description]'}
                                value1={formik.values?.translations?.[1]['description']}
                                label1={'RU Description'}
                                onChange2={formik.handleChange}
                            />
                            <FieldSetComponent
                                name1={'translations[2][description]'}
                                value1={formik.values?.translations?.[2]['description']}
                                label1={'EN Description'}
                                onChange2={formik.handleChange}
                            />
                        </div>
                        <div className='box2'>
                            <SelectComponent cls='is-active' b='Is active: ' name='is_active'
                                             options={[
                                                 {value: 'yes', content: 'yes'},
                                                 {value: 'no', content: 'no'}
                                             ]}
                                             handleChange={formik.handleChange}
                            />
                            <SelectComponent2 cls='work-category-id' b='Work category: ' name='work_category_id'
                                              handleChange={formik.handleChange}
                                              options={work_category}
                            />
                            <SelectComponent2 cls='work-hours-id' b='Work hours: ' name='working_hours_id'
                                              handleChange={formik.handleChange}
                                              options={work_category_hours}
                            />
                            <SelectComponent2 cls='locality-code' b='Location: ' name='locality_code'
                                              handleChange={formik.handleChange}
                                              options={locality}
                            />
                            <span>
                                <div className='flex'>
                            <b ref={b}>Requirements</b>
                            <CheckboxComponent
                                options={requirements}
                                handleChange={v => formik.setFieldValue('requirements', v.map(item => ({requirement_id: item.id})))}
                            />
                                </div>
                            </span>
                            <DataTimePicker
                                cls='dataPiker'
                                func={(v) => formik.values.deadline = v.split('/')[0]}/>
                        </div>
                    </FormikProvider>
                </div>
                <Button
                    className='form-send'
                    type='submit'>
                    Create
                </Button>
            </form>
        </div>
    );
}