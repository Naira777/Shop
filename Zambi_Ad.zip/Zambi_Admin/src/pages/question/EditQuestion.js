import {useDispatch, useSelector} from "react-redux";
import Button from "@mui/material/Button";
import {NewQuestion} from "./NewQuestion";
import {changeQuestionId} from "../../Redux/getQuestion/slice";
import {API} from "../../Redux/API";
import {useEffect} from "react";

export function EditQuestion() {
    const {question_data, question_id} = useSelector(state => state.question)
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(API.getQuestion());
    }, [])

    return (
        <>
            {!question_id && <div className='brand-list'>
                {question_data.map(item => <Button
                    key={item.id}
                    variant="outlined"
                    onClick={() => {
                        dispatch(changeQuestionId(item.id))
                        dispatch(API.getOneQuestion(item.id))
                    }}>
                    {item.translation.title}
                </Button>)}
            </div>}
            {question_id && <NewQuestion/>}
        </>
    );
}