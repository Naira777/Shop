import Button from "@mui/material/Button";
import {FormikProvider, useFormik} from "formik";
import {useDispatch, useSelector} from "react-redux";
import {SelectComponent} from "../../components/SelectComponent";
import {FieldSetComponent} from "../../components/FieldSet";
import axios from "../../helpers/axios/axiosPost";
import {useEffect} from "react";
import {API} from "../../Redux/API";
import {changeQuestionId} from "../../Redux/getQuestion/slice";
import {useNavigate} from "react-router-dom";
import {loading, reject} from "../../helpers/loading";

export function NewQuestion() {
    const navigate = useNavigate()
    const path = window.location.pathname === '/newQuestion'
    const dispatch = useDispatch();
    const update = () => {
        dispatch(API.getQuestion())
        dispatch(changeQuestionId(null))
    }
    const {question_id, one_question_data} = useSelector(state => state.question);
    const postFunction = (data) => {
        loading(true)
        axios.post('admin-api/question', data)
            .then(_ => {
                update();
                navigate('/editQuestion');
                loading(false)
            })
            .catch(reject)
    }
    const deleteFunction = () => {
        const del = window.confirm('Delete?')
        if (del) {
            loading(true)
            del && axios.delete(`admin-api/question/${question_id}`)
                .then(_ => {
                    update()
                    loading(false)
                })
                .catch(reject)
        }
    }
    const formik = useFormik({
        initialValues: {
            id: question_id,
            is_active: 'yes',
            translations: [
                {
                    lang_code: 'am',
                    title: '',
                    description: ''
                },
                {
                    lang_code: 'en',
                    title: '',
                    description: ''
                },
                {
                    lang_code: 'ru',
                    title: '',
                    description: ''
                }
            ],
        },

        onSubmit: () => postFunction(formik.values)
    })
    useEffect(() => {
        !path && formik.setValues(one_question_data)
    }, [one_question_data]);

    return (
        <div className='form-div'>
            <form className='new-question-form' onSubmit={formik.handleSubmit}>
                <div className='main'>
                    <FormikProvider value={formik}>
                        <SelectComponent cls='is-active' b='Is Active: ' name='is_active' options={[
                            {value: 'yes', content: 'yes'},
                            {value: 'no', content: 'no'}
                        ]}/>
                        <div className='box'>
                            <legend>Translations</legend>
                            <FieldSetComponent
                                name1={'translations[0][title]'}
                                name2={'translations[0][description]'}
                                value1={formik.values?.translations?.[0]['title']}
                                value2={formik.values?.translations?.[0]['description']}
                                label1={'AM Title'}
                                label2={'AM Description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                            <FieldSetComponent
                                name1={'translations[1][title]'}
                                name2={'translations[1][description]'}
                                value1={formik.values?.translations?.[1]['title']}
                                value2={formik.values?.translations?.[1]['description']}
                                label1={'EN Title'}
                                label2={'EN Description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                            <FieldSetComponent
                                name1={'translations[2][title]'}
                                name2={'translations[2][description]'}
                                value1={formik.values?.translations?.[2]['title']}
                                value2={formik.values?.translations?.[2]['description']}
                                label1={'RU Title'}
                                label2={'RU Description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                            {(path ? (
                                <Button
                                    className='form-send'
                                    type='submit'>
                                    Create question
                                </Button>
                            ) : (
                                <Button
                                    className='delete'
                                    onClick={deleteFunction}>
                                    Delete
                                </Button>
                            ))}
                        </div>
                    </FormikProvider>
                </div>
            </form>
        </div>
    );
}