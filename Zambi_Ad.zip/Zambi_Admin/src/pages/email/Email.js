import {useDispatch, useSelector} from "react-redux";
import {API} from "../../Redux/API";
import {useEffect} from "react";
import {Button} from "@mui/material";
import axiosPost from "../../helpers/axios/axiosPost";

export function Email() {
    const dispatch = useDispatch();
    const {email_data} = useSelector(state => state.email)
    useEffect(() => {
        dispatch(API.getEmail());
    }, [dispatch])
    const deleteFunction = (id) => {
        axiosPost.delete(`admin-api/send-email/${id}`)
            .then(_ => dispatch(API.getEmail()))
    }
    return (
        <>
            <div className='email-list'>
                <h1>Emails</h1>
                {email_data?.map(item => (
                    <div key={item.id} className='email'>
                        <h2><b>Email: </b>{item.email}</h2>
                        <h2><b>Type: </b>{item.type}</h2>
                        <Button variant="contained" className='delete'
                                onClick={() => deleteFunction(item.id)}>Delete</Button>
                    </div>
                ))}
            </div>
        </>
    );
}