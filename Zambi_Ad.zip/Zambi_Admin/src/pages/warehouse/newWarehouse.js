import {Button, TextField} from "@mui/material";
import {FormikProvider, useFormik} from "formik";
import {useDispatch, useSelector} from "react-redux";
import axios from "../../helpers/axios/axiosPost";
import {FieldSetComponent} from "../../components/FieldSet";
import {SelectComponent} from "../../components/SelectComponent";
import './warehouse.scss'
import {changeWarehouseId} from "../../Redux/getWarehouse/slice";
import {API} from "../../Redux/API";
import {useNavigate} from "react-router-dom";
import {useEffect} from "react";
import {loading, reject} from "../../helpers/loading";

export function NewWarehouse() {
    const path = window.location.pathname === '/newWarehouse'
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const update = () => {
        dispatch(changeWarehouseId(null));
        dispatch(API.getWarehouse());
        navigate('/editWarehouse')
    }
    const {warehouse_id, one_warehouse_data} = useSelector(state => state.warehouse);
    const postFunction = (data) => {
        loading(true)
        axios.post('admin-api/warehouse', data, {headers: {"Content-Type": "application/json"}})
            .then(_ => {
                update()
                loading(false)
            })
            .catch(reject)
    }
    const updateFunction = (data) => {
        loading(true)
        axios.post(`admin-api/warehouse/${warehouse_id}`, data, {headers: {"Content-Type": "application/json"}})
            .then(_ => {
                update();
                loading(false);
            })
            .catch(reject)
    }
    const deleteFunction = () => {
        const del = window.confirm('Delete?')
        loading(true)
        del && axios.delete(`admin-api/warehouse/${warehouse_id}`, {headers: {"Content-Type": "application/json"}}).then(_ => {
            loading(false)
            update()
        })
    }
    const formik = useFormik({
        initialValues: {
            is_active: 'yes',
            translations: [
                {
                    lang_code: 'am',
                    name: '',
                    address: '',
                    description: '',
                },
                {
                    lang_code: 'ru',
                    name: '',
                    address: '',
                    description: '',
                },
                {
                    lang_code: 'en',
                    name: '',
                    address: '',
                    description: '',
                }
            ],
            latitude: '',
            longitude: ''
        },
        onSubmit: () => {
            path ? postFunction(formik.values) : updateFunction(formik.values);
        }
    })
    useEffect(() => {
        !path && formik.setValues(one_warehouse_data)
    }, [one_warehouse_data]);

    return (
        <div className='form-div'>
            <form className='new-warehouse-form' onSubmit={formik.handleSubmit}>
                <div className='main'>
                    <FormikProvider value={formik}>
                        <div className='whb'>
                            <SelectComponent cls='is-active' b='Is active: ' name='is_active' options={[
                                {value: 'yes', content: 'yes'},
                                {value: 'no', content: 'no'}
                            ]}/>
                            <TextField
                                label="Latitude"
                                variant="standard"
                                type='text'
                                name='latitude'
                                value={formik.values.latitude}
                                required
                                placeholder='Example: 40.1967961'
                                onChange={formik.handleChange}
                            />
                            <TextField
                                label="Longitude"
                                variant="standard"
                                type='text'
                                name='longitude'
                                value={formik.values.longitude}
                                required
                                placeholder='Example: 44.4680669'
                                onChange={formik.handleChange}
                            />
                        </div>
                        <div className='box1 warehouse'>
                            <legend>Translations</legend>
                            <FieldSetComponent
                                name1={'translations[0][name]'}
                                name2={'translations[0][address]'}
                                name3={'translations[0][description]'}
                                value1={formik.values?.translations?.[0]?.['name']}
                                value2={formik.values?.translations?.[0]?.['address']}
                                value3={formik.values?.translations?.[0]?.['description']}
                                label1={'AM name'}
                                label2={'AM address'}
                                label3={'AM description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                                onChange3={formik.handleChange}
                            />
                            <FieldSetComponent
                                name1={'translations[1][name]'}
                                name2={'translations[1][address]'}
                                name3={'translations[1][description]'}
                                value1={formik.values?.translations?.[1]?.['name']}
                                value2={formik.values?.translations?.[1]?.['address']}
                                value3={formik.values?.translations?.[1]?.['description']}
                                label1={'RU name'}
                                label2={'RU address'}
                                label3={'RU description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                                onChange3={formik.handleChange}
                            />
                            <FieldSetComponent
                                name1={'translations[2][name]'}
                                name2={'translations[2][address]'}
                                name3={'translations[2][description]'}
                                value1={formik.values?.translations?.[2]?.['name']}
                                value2={formik.values?.translations?.[2]?.['address']}
                                value3={formik.values?.translations?.[2]?.['description']}
                                label1={'EN name'}
                                label2={'EN address'}
                                label3={'EN description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                                onChange3={formik.handleChange}
                            />
                            {!path ? (
                                <span className='buttons'>
                                    <Button
                                        className='form-send'
                                        type='submit'>
                                    Update
                                </Button>
                                    <Button
                                        className='delete'
                                        onClick={deleteFunction}>
                                    Delete
                                </Button>
                                </span>
                            ) : (
                                <Button
                                    className='form-send'
                                    type='submit'>
                                    Create Warehouse
                                </Button>
                            )}
                        </div>
                    </FormikProvider>
                </div>
            </form>
        </div>
    );
}