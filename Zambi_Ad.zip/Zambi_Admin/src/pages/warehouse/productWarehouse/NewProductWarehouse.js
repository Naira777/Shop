import Button from "@mui/material/Button";
import {useFormik} from "formik";
import {useDispatch, useSelector} from "react-redux";
import axiosPost from "../../../helpers/axios/axiosPost";
import {API} from "../../../Redux/API";
import {changeWarehouseId} from "../../../Redux/getWarehouse/slice";
import {changeCategoryId} from "../../../Redux/getCategory/slice";
import {changeAllProductId} from "../../../Redux/getAllProduct/slice";
import {changeBrandId2} from "../../../Redux/getBrand/slice";
import {changeProductId} from "../../../Redux/getProduct/slice";

export function NewProductWarehouse() {
    const {warehouse_id} = useSelector(state => state.warehouse);
    const {product_id} = useSelector(state => state.product);
    const dispatch = useDispatch()
    const clearId = () => {
        dispatch(changeWarehouseId(null))
        dispatch(changeCategoryId(null))
        dispatch(changeAllProductId(null))
        dispatch(changeBrandId2(null))
        dispatch(changeProductId(null))
    }

    const postFunction = (data) => {
        axiosPost.post(`${process.env.REACT_APP_BASE_URL}admin-api/product-warehouse`, data)
            .then(_ => {
                clearId()
                dispatch(API.getWarehouse());
            })
    }
    const updateFunction = (data) => {
        axiosPost.post(`${process.env.REACT_APP_BASE_URL}admin-api/product-warehouse/${warehouse_id}`, data)
            .then(_ => {
                clearId()
                dispatch(API.getWarehouse());
            })
    }
    const deleteFunction = () => {
        axiosPost.delete(`${process.env.REACT_APP_BASE_URL}admin-api/product-warehouse/${warehouse_id}`)
            .then(_ => {
                clearId()
               dispatch(API.getWarehouse());
            })
    }
    const path = window.location.pathname === '/newProductWarehouse'

    const formik = useFormik({
        initialValues: {
            warehouse_id: warehouse_id,
            product_id: product_id,
            quantity: 1,
        },
        onSubmit: () => {
            path ? postFunction(formik.values) : updateFunction(formik.values);
        }
    })

    return (
        <div className='form-div'>
            <form className='new-warehouse-form' onSubmit={formik.handleSubmit}>
                <div className='main'>
                            <span className='quantity'>
                                <b>Quantity: </b>
                                <input
                                    type="number"
                                    name='quantity'
                                    min='1'
                                    required
                                    value={formik.values.quantity}
                                    step='1'
                                    onChange={formik.handleChange}/>
                            </span>
                </div>
                {(window.location.pathname === '/editProductWarehouse' && (
                    <span className='buttons'>
                                    <Button
                                        className='form-send'
                                        type='submit'>
                                    Update
                                </Button>
                                    <Button
                                        className='delete'
                                        onClick={deleteFunction}>
                                    Delete
                                </Button>
                                </span>
                ))}
                {(window.location.pathname === '/newProductWarehouse' && (
                    <Button
                        className='form-send'
                        type='submit'>
                        Add Product Warehouse
                    </Button>
                ))}
            </form>
        </div>
    );
}