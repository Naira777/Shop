import {useDispatch, useSelector} from "react-redux";
import Button from "@mui/material/Button";
import {changeWarehouseId} from "../../../Redux/getWarehouse/slice";
import {changeAllProductId} from "../../../Redux/getAllProduct/slice";
import {NewProductWarehouse} from "./NewProductWarehouse";
import {changeCategoryId} from "../../../Redux/getCategory/slice";
import {API} from "../../../Redux/API";
import {changeBrandId2} from "../../../Redux/getBrand/slice";
import {changeProductId} from "../../../Redux/getProduct/slice";
import ControlPointIcon from "@mui/icons-material/ControlPoint";
import {useEffect} from "react";

export function EditProductWarehouse() {
    const {warehouse_data, warehouse_id} = useSelector(state => state.warehouse)
    const {category_data, category_data_child, category_id2} = useSelector(state => state.productCategory);
    const {all_product_id, all_product_data, product_id} = useSelector(state => state.product);
    const {brand_id} = useSelector(state => state.brand)
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(API.getWarehouse());
        dispatch(API.getProductCategory());
    }, [dispatch])
    return (
        <>
            {!warehouse_id && <div className='warehouse-list'>
                <h1>Warehouse list</h1>
                {warehouse_data?.map(item => (
                    <div className='warehouse' key={item.id}
                         onClick={() => dispatch(changeWarehouseId(item.id))}
                    >
                        <h2><b>Is active: </b> {item.is_active}</h2>
                        <h2><b>Latitude: </b> {item.latitude}</h2>
                        <h2><b>Longitude: </b> {item.longitude}</h2>
                    </div>))}
            </div>}
            {warehouse_id && <>
                {!brand_id && <>
                    {!all_product_id && <>
                        {!category_id2 &&
                            <div className='category-list'>
                                <h1>Brand list</h1>
                                {category_data.map(item => item.parent_id && item.has_childs === 'yes' &&
                                    <Button key={item.id} variant="outlined"
                                            onClick={() => {
                                                dispatch(changeCategoryId(item.id))
                                                dispatch(API.getCategoryChild(item.id));
                                            }}>{item.translation.title}</Button>)}
                            </div>
                        }
                        {category_id2 &&
                            <div className='category-list2'>
                                <h1>Category list</h1>
                                {category_data_child.length ? category_data_child.map(item => {
                                    return (
                                        <Button key={item.id} variant="outlined"
                                                onClick={() => {
                                                    dispatch(API.getAllProductByCategory(item.id))
                                                    dispatch(changeAllProductId(item.id))
                                                }}>
                                            {item.translation.title}
                                        </Button>
                                    )
                                }) : <h2 className='empty'>Empty</h2>}
                            </div>
                        }</>}
                    {all_product_id &&
                        <div className='category-list2'>
                            <h1>Product list</h1>
                            <div className='product-list'>
                                {all_product_data?.data?.length ? all_product_data?.data?.map(item => {
                                    return (
                                        all_product_data?.data?.length > 0 ? (
                                            <div key={item.id} className='product-item' onClick={() => {
                                                dispatch(changeAllProductId(null))
                                                dispatch(changeBrandId2(item.brand_id))
                                                dispatch(changeProductId(item.id))
                                                dispatch(API.getOneProduct(item.id))
                                            }}>
                                                <img src={`${process.env.REACT_APP_BASE_URL}${item.media.medium_image}`}
                                                     alt='product'/>
                                                <div className='span'>
                                                    <h5>Price: <b>{item.price}</b></h5>
                                                    <h5>Rate: <b>{item.rate}</b></h5>
                                                </div>
                                                <h5>Measurement: <b>{item.measurement_code}</b></h5>
                                                <h5>Discounted: <b>{item.is_discounted}</b></h5>
                                            </div>
                                        ) : <h1>Empty</h1>
                                    )
                                }) : <h2 className='empty'>Empty</h2>}
                            </div>
                            {all_product_data?.links?.next &&
                                <ControlPointIcon className='plus-button'
                                                  onClick={() => dispatch(API.getNextProduct(all_product_data))}/>
                            }
                        </div>}
                </>
                }
            </>}
            {product_id && <NewProductWarehouse/>}
        </>
    );
}