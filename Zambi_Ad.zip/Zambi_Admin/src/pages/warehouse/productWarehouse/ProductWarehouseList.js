import {useDispatch, useSelector} from "react-redux";
import {API} from "../../../Redux/API";
import {useEffect, useState} from "react";
import {changeWarehouseId} from "../../../Redux/getWarehouse/slice";
import '../warehouse.scss'
import {Button} from "@mui/material";
import axios from "../../../helpers/axios/axiosPost";

export function ProductWarehouseList() {
    const [one, setOne] = useState(null);
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(API.getWarehouse());
        dispatch(changeWarehouseId(null))
    }, [dispatch]);
    const update = () => {
        dispatch(API.getWarehouse())
        dispatch(API.getOneWarehouse(one))
    }
    const {warehouse_data, one_warehouse_data, warehouse_id} = useSelector(state => state.warehouse)
    const updateFunction = (id, price, type) => axios.put(`admin-api/product-warehouse/${id}`, {
        quantity: price,
        type
    }).then(_ => update(id))

    return (
        <>
            {!warehouse_id && <div className='warehouse-list'>
                <h1>Warehouse list</h1>
                {warehouse_data?.map(item => (
                    <div className='warehouse' key={item.id}
                         onClick={() => {
                             dispatch(changeWarehouseId(item.id))
                             dispatch(API.getOneWarehouse(item.id))
                             setOne(item.id)
                         }}>
                        <h2><b>Is active: </b> {item.is_active}</h2>
                        <h2><b>Address: </b> {item.translation?.address}</h2>
                        <h2><b>Latitude: </b> {item.latitude}</h2>
                        <h2><b>Longitude: </b> {item.longitude}</h2>
                    </div>
                ))}
            </div>}
            {warehouse_id && <div className='product-ware-list'>
                <h1>Product Warehouse list</h1>
                {one_warehouse_data?.warehouse_has_products?.map(item => (
                    <div className='product-ware' key={item.id}>
                        <img src={`${process.env.REACT_APP_BASE_URL}${item.product.media.medium_image}`}
                             alt='product_img'/>
                        <h2>Quantity: <b>{item.quantity}</b></h2>
                        <Price item={item} updateFunction={updateFunction}/>
                    </div>
                ))}
            </div>}
        </>
    )
}

const Price = ({item, updateFunction}) => {
    const [price, setPrice] = useState('');
    useEffect(() => {
        setPrice("")
    }, [item]);

    return (
        <div key={item.id} className='price-update'>
            <input required
                   step='1'
                   min='1'
                   type='number'
                   value={price}
                   placeholder='Quantity'
                   onChange={(e) => setPrice(e.target.value)}/>
            <div className='buttons'>
                <Button variant="contained" className='add delete' onClick={() => {
                    updateFunction(item.id, price, 'add')
                }}>Add</Button>
                <Button variant="contained" className='delete' onClick={() => {
                    updateFunction(item.id, price, 'subtract ')
                }}>Subtract</Button>
            </div>
        </div>
    )
}