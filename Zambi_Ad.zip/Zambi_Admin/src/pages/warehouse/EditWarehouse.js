import {useDispatch, useSelector} from "react-redux";
import {NewWarehouse} from "./newWarehouse";
import {changeWarehouseId} from "../../Redux/getWarehouse/slice";
import {API} from "../../Redux/API";
import {useEffect} from "react";

export function EditWarehouse() {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(API.getWarehouse());
    }, [dispatch]);
    const {warehouse_data, warehouse_id} = useSelector(state => state.warehouse)

    return (
        <>
            {!warehouse_id && <div className='warehouse-list'>
                <h1>Warehouse list</h1>
                {warehouse_data?.map(item => (
                    <div className='warehouse w' key={item.id}
                         onClick={() => {
                             dispatch(API.getOneWarehouse(item.id))
                             dispatch(changeWarehouseId(item.id))
                         }}
                    >
                        <h2><b>Name: </b> {item.translation?.name}</h2>
                        <h2><b>Address: </b> {item.translation?.address}</h2>
                        <h2><b>Description: </b> {item.translation?.description}</h2>
                        <h2><b>Is active: </b> {item.is_active}</h2>
                        <h2><b>Latitude: </b> {item.latitude}</h2>
                        <h2><b>Longitude: </b> {item.longitude}</h2>
                    </div>
                ))}
            </div>}
            {warehouse_id && <NewWarehouse/>}
        </>
    );
}