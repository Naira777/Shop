import {useDispatch, useSelector} from "react-redux";
import {API} from "../../Redux/API";
import {useEffect} from "react";
import {Button} from "@mui/material";
import axiosPost from "../../helpers/axios/axiosPost";

export function Providers() {
    const dispatch = useDispatch();
    const {provider_data} = useSelector(state => state.provider)
    useEffect(() => {
        dispatch(API.getProvider());
    }, [dispatch])
    const deleteFunction = (id) => {
        axiosPost.delete(`admin-api/provider/${id}`)
            .then(_ => dispatch(API.getProvider()))
    }

    return (
        <div className='provider-list'>
            <h1>Providers</h1>
            {provider_data.length ? provider_data.map(item => (
                    <div className='provider' key={item.id}>
                        <h2><b>Comment: </b>{item.comment}</h2>
                        <h2><b>Company: </b>{item.company}</h2>
                        <h2><b>Full name: </b>{item.full_name}</h2>
                        <h2><b>Phone number: </b>{item.phone_number}</h2>
                        <Button variant="contained" className='delete'
                                onClick={() => deleteFunction(item.id)}>Delete</Button>
                    </div>
                ))
                : <h2 className='empty'>Empty</h2>}
        </div>
    );
}