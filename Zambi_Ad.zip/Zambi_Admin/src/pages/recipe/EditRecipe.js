import {useDispatch, useSelector} from "react-redux";
import {NewRecipe} from "./NewRecipe";
import {changeRecipeId} from "../../Redux/getRecipe/slice";
import {API} from "../../Redux/API";
import {useEffect} from "react";
import './recipe.scss';

export function EditRecipe() {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(API.getAllRecipe());
    }, [dispatch])
    const {all_recipe_data, recipe_id} = useSelector(state => state.recipe)
    return (
        <>
            {!recipe_id && <div className='recipe-list'>
                <h1>Recipe Category</h1>
                {all_recipe_data?.map(item => (
                    <div key={item.id} className='product-item'
                         onClick={() => {
                             dispatch(changeRecipeId(item.id))
                             dispatch(API.getOneRecipe(item.id))
                         }}>
                        <img src={`${process.env.REACT_APP_BASE_URL}${item.media.medium_image}`} alt='recipe-img :('/>
                        <h5>Recipe type: <b>{item.recipe_type?.translation?.title}</b></h5>
                        <h5>Rate: <b>{item.rate}</b></h5>
                        <h5>Time: <b>{item.time}</b></h5>
                    </div>
                ))}
            </div>}
            {recipe_id && <NewRecipe/>}
        </>
    );
}