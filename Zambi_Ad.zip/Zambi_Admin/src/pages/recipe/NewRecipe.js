import Button from "@mui/material/Button";
import {FormikProvider, useFormik} from "formik";
import {useDispatch, useSelector} from "react-redux";
import axiosPost from "../../helpers/axios/axiosPost";
import {SelectComponent} from "../../components/SelectComponent";
import {FieldSetComponent} from "../../components/FieldSet";
import axiosGet from "../../helpers/axios/axiosGet";
import React, {useEffect, useState} from "react";
import {API} from "../../Redux/API";
import {changeRecipeId} from "../../Redux/getRecipe/slice";
import CheckboxComponent from "../../components/MultipleSelect";
import Ingredient from "./Ingredient";
import {useNavigate} from "react-router-dom";
import {loading, reject} from "../../helpers/loading";

export function NewRecipe() {
    const path = window.location.pathname === '/newRecipe';
    const {recipe_id, one_recipe} = useSelector(state => state.recipe);
    const [type, setType] = useState([]);
    const [category, setCategory] = useState([]);
    const [productList, setProductList] = useState([]);
    const [image, setImage] = useState();
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const update = () => {
        dispatch(API.getAllRecipe())
        dispatch(changeRecipeId(null))
        navigate('/editRecipe')
    }
    const formik = useFormik({
        initialValues: {
            rate: '1',
            time: '10',
            translations: [
                {
                    lang_code: 'am',
                    title: '',
                    description: ''
                },
                {
                    lang_code: 'en',
                    title: '',
                    description: ''
                },
                {
                    lang_code: 'ru',
                    title: '',
                    description: ''
                }
            ],
            recipe_process: {
                translations: [
                    {
                        lang_code: 'am',
                        process: '',
                    },
                    {
                        lang_code: 'en',
                        process: '',
                    },
                    {
                        lang_code: 'ru',
                        process: '',
                    }
                ],
            },
            recipe_ingredient: [
                {
                    translations: [
                        {
                            ingredient: '',
                            lang_code: 'am',
                        },
                        {
                            ingredient: '',
                            lang_code: 'en',
                        },
                        {
                            ingredient: '',
                            lang_code: 'ru',
                        }
                    ],
                }
            ]
        },
        onSubmit: () => {
            path ? postFunction(formik.values) : updateFunction(formik.values);
        }
    })
    const [ingredient, setIngredient] = useState(formik.values);
    const UpdateIngredient = (index) => axiosPost.post(`admin-api/recipe/ingredient/${formik.values.recipe_ingredient[index].id}`, {recipe_ingredient: formik.values.recipe_ingredient[index]}).then(_ => dispatch(API.getOneRecipe(recipe_id)))
    const DeleteIngredient = (id, index) => {
        axiosPost.delete(`admin-api/recipe/ingredient/${id}`).then(_ => {
            dispatch(API.getOneRecipe(index)).then(_ => formik.setFieldValue('recipe_ingredient', one_recipe))
        })
    }

    const postFunction = (data) => {
        loading(true)
        API.uploadImage({image}).then(id => {
            axiosPost.post('admin-api/recipe', {...data, media_id: id.data.id})
                .then(_ => {
                    update();
                    loading(false)
                })
                .catch(reject)
        })
    }

    function update1(data) {
        loading(true)
        API.updateImage({image, media_id: one_recipe.media_id}).then(id => {
            axiosPost.post(`admin-api/recipe/${recipe_id}`, {...data, media_id: id.data.id})
                .then(_ => {
                    update()
                    loading(false)
                })
                .catch(reject)
        })
    }

    function update2(data) {
        loading(true)
        axiosPost.post(`admin-api/recipe/${recipe_id}`, data)
            .then(_ => {
                update()
                loading(false)
            })
            .catch(reject)
    }

    const updateFunction = (data) => image ? update1(data) : update2(data);
    const deleteFunction = () => {
        const del = window.confirm('Delete?');
        del && axiosPost.delete(`admin-api/recipe/${recipe_id}`).then(update);
    }

    const rate = [
        {value: '1', content: '1'},
        {value: '2', content: '2'},
        {value: '3', content: '3'},
        {value: '4', content: '4'},
        {value: '5', content: '5'}
    ]

    const add = () => {
        formik.setFieldValue(`recipe_ingredient`, [...formik.values.recipe_ingredient, {
            translations: [
                {
                    ingredient: '',
                    lang_code: 'am',
                },
                {
                    ingredient: '',
                    lang_code: 'en',
                },
                {
                    ingredient: '',
                    lang_code: 'ru',
                }
            ]
        }])
        setIngredient([...formik.values.recipe_ingredient, {
            translations: [
                {
                    ingredient: '',
                    lang_code: 'am',
                },
                {
                    ingredient: '',
                    lang_code: 'en',
                },
                {
                    ingredient: '',
                    lang_code: 'ru',
                }
            ]
        }])
    }
    const remove = () => {
        const newIngredient = [...formik.values.recipe_ingredient];
        newIngredient.pop();
        setIngredient(newIngredient)
        formik.setFieldValue(`recipe_ingredient`, ingredient)
    }
    useEffect(() => {
        axiosGet.get('api/recipe/type').then(data => setType(data.data.data.map(item => (
            {
                value: item.id,
                content: item.translation?.title
            }
        ))))
        axiosGet.get('api/recipe/category').then(data => setCategory(data.data.data.map(item => (
            {
                value: item.id,
                content: item.translation?.title
            }
        ))))
        axiosGet.get('api/product?filter_by_is_express=all&filter_by_product_type=all&filter_by_main_filter=all&category=all')
            .then(data => setProductList(data.data.data))
    }, [one_recipe]);
    useEffect(() => {
        if (path) {
            formik.values.recipe_category = `${category[0]?.value}`
            formik.values.recipe_type = `${type[0]?.value}`
        } else {
            formik.setValues(one_recipe)
        }
    }, [one_recipe, category, type]);

    return (
        <div className='form-div'>
            <form className='new-recipe-form' onSubmit={formik.handleSubmit}>
                <div className='main'>
                    <FormikProvider value={formik}>
                        <div className='select-box'>
                            <SelectComponent cls='type' b='Recipe type: ' name='recipe_type' options={type}/>
                            <SelectComponent cls='type' b='Category type: ' name='recipe_category' options={category}/>
                            <SelectComponent cls='type' b='rate: ' name='rate' options={rate}/>
                            <div className='recipe-products'>
                                <b>Recipe products: </b>
                                <CheckboxComponent
                                    options={productList}
                                    handleChange={v => formik.setFieldValue('recipe_product', v.map(item => ({id: item.id})))}
                                />
                            </div>
                            <span className='time'>
                                <b>time: </b>
                                <input
                                    required
                                    type="number"
                                    name='time'
                                    min='0'
                                    value={formik.values?.time}
                                    step='5'
                                    onChange={formik.handleChange}/>
                            </span>
                            <div className='box2'>
                                <legend>Recipe process</legend>
                                <FieldSetComponent
                                    name1={'recipe_process[translations][0][process]'}
                                    value1={formik.values?.recipe_process?.translations?.[0]?.['process']}
                                    label1={'AM Process'}
                                    onChange2={formik.handleChange}
                                />
                                <FieldSetComponent
                                    name1={'recipe_process[translations][1][process]'}
                                    value1={formik.values?.recipe_process?.translations?.[1]?.['process']}
                                    label1={'EN Process'}
                                    onChange2={formik.handleChange}
                                />
                                <FieldSetComponent
                                    name1={'recipe_process[translations][2][process]'}
                                    value1={formik.values?.recipe_process?.translations?.[2]?.['process']}
                                    label1={'RU Process'}
                                    onChange2={formik.handleChange}
                                />
                            </div>
                            {(!path && (
                                <span className='buttons'>
                                    <Button
                                        type='submit'
                                        className='form-send'>
                                        Update
                                    </Button>
                                    <Button
                                        className='delete'
                                        onClick={deleteFunction}>
                                        Delete
                                    </Button>
                                </span>
                            ))}
                            {path && (
                                <Button
                                    className='form-send'
                                    type='submit'>
                                    Create recipe
                                </Button>
                            )}
                        </div>
                        <div className='main-box'>
                            <span className='file'>
                                <b>Image: </b>
                                <input
                                    type='file'
                                    name='image'
                                    required={path}
                                    onChange={(e) => setImage(e.currentTarget.files[0])}
                                />
                            </span>
                            <div className='box1'>
                                <legend>Translations</legend>
                                <FieldSetComponent
                                    name1={'translations[0][title]'}
                                    name2={'translations[0][description]'}
                                    value1={formik.values?.translations?.[0]?.['title']}
                                    value2={formik.values?.translations?.[0]?.['description']}
                                    label1={'AM Title'}
                                    label2={'AM Description'}
                                    onChange={formik.handleChange}
                                    onChange2={formik.handleChange}
                                />
                                <FieldSetComponent
                                    name1={'translations[1][title]'}
                                    name2={'translations[1][description]'}
                                    value1={formik.values?.translations?.[1]?.['title']}
                                    value2={formik.values?.translations?.[1]?.['description']}
                                    label1={'EN Title'}
                                    label2={'EN Description'}
                                    onChange={formik.handleChange}
                                    onChange2={formik.handleChange}
                                />
                                <FieldSetComponent
                                    name1={'translations[2][title]'}
                                    name2={'translations[2][description]'}
                                    value1={formik.values?.translations?.[2]?.['title']}
                                    value2={formik.values?.translations?.[2]?.['description']}
                                    label1={'RU Title'}
                                    label2={'RU Description'}
                                    onChange={formik.handleChange}
                                    onChange2={formik.handleChange}
                                />
                            </div>
                            <Ingredient values={formik.values?.recipe_ingredient}
                                        formik={formik}
                                        updateIngredient={UpdateIngredient}
                                        deleteIngredient={DeleteIngredient}
                            />
                            {path && <div className='buttons'>
                                <Button onClick={add}>Add ingredient</Button>
                                {formik.values.recipe_ingredient.length > 1 &&
                                    <Button onClick={remove}>Remove ingredient</Button>}
                            </div>}
                        </div>
                    </FormikProvider>
                </div>

            </form>
        </div>
    );
}