import React from 'react';
import {FieldSetComponent} from "../../components/FieldSet";
import Button from "@mui/material/Button";
import {useSelector} from "react-redux";

const Ingredient = ({values, formik, updateIngredient, deleteIngredient}) => {
    const {one_recipe} = useSelector(state => state.recipe);
    const path = window.location.pathname === '/newRecipe';
    const ingredientData = Array.isArray(values) ? values : values?.recipe_ingredient

    return ingredientData?.map((item, index) => (
            <div className='box3' key={index}>
                <legend>Ingredient</legend>
                <FieldSetComponent
                    name1={`recipe_ingredient[${index}][translations][0][ingredient]`}
                    value1={item.translations?.[0]?.['ingredient']}
                    label1={'AM Ingredient'}
                    onChange2={formik.handleChange}
                />
                <FieldSetComponent
                    name1={`recipe_ingredient[${index}][translations][1][ingredient]`}
                    value1={item.translations?.[1]?.['ingredient']}
                    label1={'EN Ingredient'}
                    onChange2={formik.handleChange}
                />
                <FieldSetComponent
                    name1={`recipe_ingredient[${index}][translations][2][ingredient]`}
                    value1={item.translations?.[2]?.['ingredient']}
                    label1={'RU Ingredient'}
                    onChange2={formik.handleChange}
                />
                {!path && <div className='buttons'>
                    <Button onClick={() => updateIngredient(index)}>Update</Button>
                    {one_recipe?.recipe_ingredient?.length > 1 &&
                        <Button onClick={() => deleteIngredient(item.id, one_recipe.id)}>Delete</Button>}
                </div>}
            </div>
        )
    )
}

export default Ingredient;
