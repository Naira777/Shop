import './product.scss';
import {API} from "../../Redux/API";
import Button from "@mui/material/Button";
import {useDispatch, useSelector} from "react-redux";
import {NewProduct} from "./NewProduct";
import {changeCategoryId} from "../../Redux/getCategory/slice";
import {changeBrandId2} from "../../Redux/getBrand/slice";
import {changeAllProductId} from "../../Redux/getAllProduct/slice";
import {useEffect} from "react";
import ControlPointIcon from "@mui/icons-material/ControlPoint";
import {changeDiscountId, changeProductId} from "../../Redux/getProduct/slice";

export function EditProduct() {
    const {category_data, category_data_child, category_id2} = useSelector(state => state.productCategory);
    const {all_product_id, all_product_data} = useSelector(state => state.product);
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(API.getProductCategory());
        dispatch(API.getBrandList());
    }, [dispatch])
    const {brand_id} = useSelector(state => state.brand)
    return (
        <>
            {!brand_id && <>
                {!all_product_id && <>
                    {!category_id2 &&
                        <div className='category-list'>
                            <h1>Parent category list</h1>
                            {category_data.map(item => item.parent_id && item.has_childs === 'yes' &&
                                <Button key={item.id} variant="outlined"
                                        onClick={() => {
                                            dispatch(changeCategoryId(item.id))
                                            dispatch(API.getCategoryChild(item.id));
                                            dispatch(API.getBrandListByCategory(item.id));
                                        }}>{item.translation.title}</Button>)}
                        </div>
                    }
                    {category_id2 &&
                        <div className='category-list2'>
                            <h1>Child category list</h1>
                            {category_data_child.length ? category_data_child.map(item => {
                                return (
                                    <Button key={item.id} variant="outlined"
                                            onClick={() => {
                                                dispatch(API.getAllProductByCategory(item.id))
                                                dispatch(changeAllProductId(item.id))
                                            }}>
                                        {item.translation.title}
                                    </Button>
                                )
                            }) : <h2 className='empty'>Empty</h2>}
                        </div>
                    }</>}
                {all_product_id &&
                    <div className='category-list2'>
                        <h1>Product list</h1>
                        <div className='product-list'>
                            {all_product_data?.data?.length ? all_product_data?.data?.map(item => {
                                return (
                                    all_product_data?.data?.length > 0 ? (
                                        <div key={item.id} className='product-item' onClick={() => {
                                            dispatch(changeAllProductId(null))
                                            dispatch(changeBrandId2(item.brand_id))
                                            dispatch(changeProductId(item.id))
                                            dispatch(API.getOneProduct(item.id))
                                            dispatch(changeDiscountId(item.discount.id))
                                        }}>
                                            <img src={`${process.env.REACT_APP_BASE_URL}${item.media.medium_image}`}
                                                 alt='product'/>
                                            <div className='span'>
                                                <h5>Price: <b>{item.price}</b></h5>
                                                <h5>Rate: <b>{item.rate}</b></h5>
                                            </div>
                                            <h5>Title: <b>{item.translation.title}</b></h5>
                                            <h5>Measurement: <b>{item.measurement_code}</b></h5>
                                            <h5>Discounted: <b>{item.is_discounted}</b></h5>
                                        </div>
                                    ) : <h1>Empty</h1>
                                )
                            }) : <h2 className='empty'>Empty</h2>}
                        </div>
                        {all_product_data?.links?.next &&
                            <ControlPointIcon className='plus-button'
                                              onClick={() => dispatch(API.getNextProduct(all_product_data))}/>
                        }
                    </div>}
            </>
            }
            {brand_id && <NewProduct/>}
        </>
    )
}