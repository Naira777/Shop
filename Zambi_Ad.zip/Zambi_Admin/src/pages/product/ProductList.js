import './product.scss';
import {useDispatch, useSelector} from "react-redux";
import {API} from "../../Redux/API";
import Button from "@mui/material/Button";
import {NewProduct} from "./NewProduct";
import {changeCategoryId} from "../../Redux/getCategory/slice";
import {changeBrandId2} from "../../Redux/getBrand/slice";
import {useEffect} from "react";

export function ProductList() {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(API.getProductCategory());
        dispatch(API.getBrandList());
    }, [dispatch])
    const {category_data, category_data_child, category_id2} = useSelector(state => state.productCategory)
    const {brand_id} = useSelector(state => state.brand)
    return (
        <>
            {!brand_id && <>
                {!category_id2 &&
                    <div className='category-list'>
                        <h1>Parent category list</h1>
                        {category_data.map(item => item.parent_id && item.has_childs === 'yes' &&
                            <Button key={item.id} variant="outlined"
                                    onClick={() => {
                                        dispatch(changeCategoryId(item.id));
                                        dispatch(API.getCategoryChild(item.id));
                                        dispatch(API.getBrandListByCategory(item.id));
                                    }}>{item.translation.title}
                            </Button>)}
                    </div>
                }
                {category_id2 &&
                    <div className='category-list2'>
                        <h1>Child category list</h1>
                        {category_data_child.map(item => (
                            <Button key={item.id}
                                    variant="outlined"
                                    onClick={() => {
                                        dispatch(changeBrandId2(item.id))
                                    }}>
                            {item.translation.title}
                            </Button>))}
                    </div>
                }
            </>
            }
            {brand_id && <NewProduct/>}
        </>
    )
}