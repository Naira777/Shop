import Button from "@mui/material/Button";
import {useFormik} from "formik";
import {useDispatch, useSelector} from "react-redux";
import axiosP from "../../helpers/axios/axiosPost";
import {useEffect} from "react";
import {API} from "../../Redux/API";
import {changeBrandId2} from "../../Redux/getBrand/slice";
import {loading, reject} from "../../helpers/loading";

export function NewDiscountProduct() {
    const {one_product, product_id, discount_id} = useSelector(state => state.product);
    const {category_id2} = useSelector(state => state.productCategory)
    const dispatch = useDispatch();
    const update = () => {
        dispatch(changeBrandId2(null))
        dispatch(API.getApply())
        dispatch(API.getDiscount(category_id2))
    }
    const postFunction = (data) => {
        console.log(product_id)
        loading(true)
        axiosP.post(`admin-api/product-discount/${product_id}`, data)
            .then(_ => {
                update()
                loading(false)
            })
            .catch(reject)
    }
    const updateFunction = (data) => {
        loading(true)
        axiosP.put(`admin-api/product-discount/${discount_id}`, data)
            .then(_ => {
                update()
                loading(false)
            })
            .catch(reject)
    }
    const deleteFunction = () => {
        const del = window.confirm('Delete?')
        loading(true)
        del && axiosP.delete(`admin-api/product-discount/${discount_id}`).then(_ => {
            update()
            loading(false)
        })
    }

    useEffect(() => {
        dispatch(API.getApply())
    }, [dispatch]);

    const formik = useFormik({
        initialValues: {
            discounted_price: '',
            percent: '',
        },
        onSubmit: () => {
            one_product?.discount ? updateFunction(formik.values) : postFunction(formik.values);
        }
    });

    useEffect(() => {
        const empty = {
            discounted_price: '',
            percent: ''
        }
        const dis = one_product?.discount;
        one_product?.discount ? formik.setValues(dis) : formik.setValues(empty)
    }, [one_product?.discount])

    return (
        <form className='discount-form' onSubmit={formik.handleSubmit}>
            <div className='discount-box'>
                <h2>Discount Product</h2>
                <div className='discount-inputs'>
                    <div className='price'>
                        <b>Price: </b>
                        <input
                            required
                            type="number"
                            min='0'
                            name='discounted_price'
                            value={formik.values?.discounted_price}
                            placeholder='0'
                            onChange={formik.handleChange}/>
                    </div>
                    <div className='price'>
                        <b>Percent: </b>
                        <input
                            required
                            type="number"
                            name='percent'
                            value={formik.values?.percent}
                            placeholder='0'
                            min='0'
                            max='100'
                            maxLength='3'
                            onChange={formik.handleChange}/>
                    </div>
                </div>
            </div>
            {one_product?.discount ? (
                <span className='buttons'>
                        <Button
                            type='submit'
                            className='form-send'>
                            UPDATE
                        </Button>
                        <Button
                            className='delete'
                            onClick={deleteFunction}>
                            Delete
                        </Button>
                    </span>
            ) : <Button
                className='form-send dis'
                type='submit'>
                Create Discount
            </Button>}
        </form>
    );
}