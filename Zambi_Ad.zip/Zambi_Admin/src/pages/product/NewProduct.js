import {FormikProvider, useFormik} from "formik";
import {useDispatch, useSelector} from "react-redux";
import axiosP from "../../helpers/axios/axiosPost";
import axiosG from "../../helpers/axios/axiosGet";
import {SelectComponent} from "../../components/SelectComponent";
import {FieldSetComponent} from "../../components/FieldSet";
import CheckboxComponent from "../../components/MultipleSelect";
import {useEffect, useRef, useState} from "react";
import {API} from "../../Redux/API";
import {changeBrandId2} from "../../Redux/getBrand/slice";
import {changeCategoryId} from "../../Redux/getCategory/slice";
import {changeAllProductId} from "../../Redux/getAllProduct/slice";
import {Button} from "@mui/material";
import {loading, reject} from "../../helpers/loading";
import {NewDiscountProduct} from "./NewDisocuntProduct";

export function NewProduct() {
    const {brand_id, brand_list, brand_list_by_category} = useSelector(state => state.brand);
    const {one_product, product_id} = useSelector(state => state.product);
    const [types, setTypes] = useState(null);
    const [measurement, setMeasurement] = useState([]);
    const [image, setImage] = useState(null);
    const dispatch = useDispatch()
    const path = window.location.pathname === '/newProduct';
    const update = () => {
        dispatch(changeBrandId2(null));
        dispatch(changeCategoryId(null));
        dispatch(changeAllProductId(null));
    }
    const postFunction = (data) => {
        loading(true)
        API.uploadImage(image).then(id => {
            axiosP.post('admin-api/product', {...data, media_id: id.data.id})
                .then(_ => {
                    update()
                    loading(false)
                })
        });
    }

    const updateFunction = (data) => {
        loading(true)
        image ? API.uploadImage(image).then(id => {
            dispatch(API.updateData({...data, media_id: id.data.id}))
                .then(_ => {
                    loading(false)
                    update()
                })
                .catch(reject)
        }) : dispatch(API.updateData(data))
            .then(_ => {
                loading(false)
                update()
            })
    }
    const deleteFunction = () => {
        const del = window.confirm('Delete?')
        del && axiosP.delete(`admin-api/product/${product_id}`).then(update);
    }
    useEffect(() => {
        axiosG.get('api/product-type')
            .then(data => setTypes(data.data.data))
        axiosG.get(`api/product-measurement`)
            .then(data => setMeasurement(data.data.data.map(item => (
                {
                    value: item.code,
                    content: item.translation.title
                }
            ))))

    }, []);

    const b = useRef();
    const formik = useFormik({
        initialValues: {
            is_express: 'yes',
            product_id,
            brand_id: brand_list?.[0]?.id,
            category_id: brand_id,
            rate: '1',
            measurement_code: 'one-piece',
            price: '',
            translations: [
                {
                    lang_code: 'am',
                    title: '',
                    description: ''
                },
                {
                    lang_code: 'en',
                    title: '',
                    description: ''
                },
                {
                    lang_code: 'ru',
                    title: '',
                    description: ''
                }
            ],
            is_discounted: 'no',
            types: [{}],
        },
        onSubmit: () => {
            path ? postFunction(formik.values) : updateFunction(formik.values);
        }
    });

    useEffect(() => {
        !path && formik.setValues(one_product);
    }, [one_product])

    return (
        <div className='form-div'>
            <h1>Product</h1>
            <form className='new-brand-form product' onSubmit={formik.handleSubmit}>
                <div className='main product'>
                    <FormikProvider value={formik}>
                        <div className='choice'>
                            <span className='file'>
                                <b>Image: </b>

                                <input
                                    type='file'
                                    required={path}
                                    onChange={(e) => setImage({'image': e.target.files[0]})}
                                />
                            </span>
                            <SelectComponent cls='type' b='Is express: ' name='is_express' options={[
                                {value: 'yes', content: 'yes'},
                                {value: 'no ', content: 'no'}
                            ]}/>
                            <SelectComponent cls='type' b='rate: ' name='rate' options={[
                                {value: '1', content: '1'},
                                {value: '2', content: '2'},
                                {value: '3', content: '3'},
                                {value: '4', content: '4'},
                                {value: '5', content: '5'}
                            ]}/>
                            <SelectComponent cls='type'
                                             b='Measurement code: '
                                             name='measurement_code'
                                             options={measurement}
                            />
                            <SelectComponent cls='type' b='Brand: ' name='brand_id'
                                             options={[...brand_list_by_category]}/>
                            <div className='flex'>
                                <b ref={b}>Types: </b>
                                <CheckboxComponent
                                    options={types}
                                    handleChange={v => formik.setFieldValue('types', v.map(item => ({product_type_code: item.code})))}
                                />
                            </div>
                            <span className='flex'>
                                <b>Price: </b>
                                <input
                                    required
                                    type="number"
                                    min='0'
                                    name='price'
                                    value={formik.values.price}
                                    placeholder='0'
                                    onChange={formik.handleChange}
                                />
                            </span>
                        </div>
                        <div className='box1'>
                            <legend>Translations</legend>
                            <FieldSetComponent
                                name1={'translations[0][title]'}
                                name2={'translations[0][description]'}
                                value1={formik.values?.translations?.[0]['title']}
                                value2={formik.values?.translations?.[0]['description']}
                                label1={'AM title'}
                                label2={'AM description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                            <FieldSetComponent
                                name1={'translations[1][title]'}
                                name2={'translations[1][description]'}
                                value1={formik.values?.translations?.[1]['title']}
                                value2={formik.values?.translations?.[1]['description']}
                                label1={'EN title'}
                                label2={'EN description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                            <FieldSetComponent
                                name1={'translations[2][title]'}
                                name2={'translations[2][description]'}
                                value1={formik.values?.translations?.[2]['title']}
                                value2={formik.values?.translations?.[2]['description']}
                                label1={'RU title'}
                                label2={'RU description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                        {!path ? (
                            <span className='buttons'>
                            <Button
                                type='submit'
                                className='form-send'>
                            UPDATE
                            </Button>
                            <Button
                                className='delete'
                                onClick={deleteFunction}>
                            Delete
                            </Button>
                            </span>
                        ) : (brand_list_by_category?.length ? (
                            <Button
                                className='form-send'
                                type='submit'>
                                Create product
                            </Button>
                        ) : <h2 className='undefined'>Category for this product doesn't exists</h2>)}
                        </div>
                    </FormikProvider>
                </div>

            </form>
            {!path && <NewDiscountProduct/>}
        </div>
    );
}