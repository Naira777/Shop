import {useDispatch, useSelector} from "react-redux";
import {changeBrandId} from "../../Redux/getCategory/slice";
import Button from "@mui/material/Button";
import {NewBrand} from "./NewBrand";
import {API} from "../../Redux/API";
import {changeBrandId2} from "../../Redux/getBrand/slice";
import {useEffect} from "react";
import {changeAllProductId} from "../../Redux/getAllProduct/slice";
import {changeProductId} from "../../Redux/getProduct/slice";

export function EditBrand() {
    const {category_data, category_id} = useSelector(state => state.productCategory)
    const {brand_data, brand_id} = useSelector(state => state.brand)
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(API.getProductCategory());
    }, [dispatch]);

    return (
        <>
            {brand_id && <NewBrand/>}
            {!brand_id && <>
                {!category_id &&
                    <div className='brand-list'>
                        <h1>Category</h1>
                        {category_data.length ? category_data.map(item => item.parent_id && item.has_childs === 'yes' &&
                                <Button key={item.id} variant="outlined"
                                        onClick={() => {
                                            dispatch(API.getBrandByCategory(item.id))
                                            dispatch(changeBrandId(item.id))
                                        }}>{item.translation.title}
                                </Button>)
                            : <h2 className='empty'>Empty</h2>}
                    </div>}
                {category_id && <div className='brand-list'>
                    <h1>Brand</h1>
                    {brand_data.length ? brand_data.map(item => (
                            <div key={item.id} className='brand-item'
                                 onClick={() => {
                                     dispatch(API.getOneBrand(item.id))
                                     dispatch(changeBrandId2(item.id))
                                 }}>
                                <img src={`${process.env.REACT_APP_BASE_URL}${item.media.medium_image}`}
                                     alt='product'/>
                                <h2>Code: <b>{item.translation.title}</b></h2>
                                <h2>Is active: <b>{item.is_active}</b></h2>
                            </div>
                        ))
                        : <h2 className='empty'>Empty</h2>}
                </div>}
            </>}
        </>
    )
}
