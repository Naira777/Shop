import {useDispatch, useSelector} from "react-redux";
import Button from '@mui/material/Button';
import {NewBrand} from "./NewBrand";
import {changeBrandId} from "../../Redux/getCategory/slice";
import './brand.scss';
import {useEffect} from "react";
import {API} from "../../Redux/API";

export function BrandListAdd() {
    const {category_data, category_id} = useSelector(state => state.productCategory)
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(API.getProductCategory());
    }, [dispatch]);

    return (
        <>
            {!category_id && <div className='brand-list'>
                <h1>Category</h1>
                {category_data.map(item => item.parent_id && item.has_childs === 'yes' &&
                    <Button key={item.id} variant="outlined" onClick={() => {
                        dispatch(changeBrandId(item.id))
                    }}>{item.translation.title}</Button>)}
            </div>}
            {category_id && <NewBrand/>}
        </>
    );
}
