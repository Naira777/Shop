import {Button} from "@mui/material";
import {FormikProvider, useFormik} from "formik";
import {useDispatch, useSelector} from "react-redux";
import {SelectComponent} from "../../components/SelectComponent";
import {FieldSetComponent} from "../../components/FieldSet";
import {API} from "../../Redux/API";
import {useEffect, useState} from "react";
import axiosPost from "../../helpers/axios/axiosPost";
import {changeBrandId2} from "../../Redux/getBrand/slice";
import {changeBrandId} from "../../Redux/getCategory/slice";
import {loading, reject} from "../../helpers/loading";

export function NewBrand() {
    const {category_id} = useSelector(state => state.productCategory);
    const {brand_id, one_brand} = useSelector(state => state.brand);
    const [image, setImage] = useState();
    const dispatch = useDispatch();
    const path = window.location.pathname === '/newBrand';
    const update = () => {
        dispatch(changeBrandId(null));
        dispatch(changeBrandId2(null));
        dispatch(API.getProductCategory());
    }
    const postFunction = (data) => {
        loading(true)
        API.uploadImage({image})
            .then(id => {
                axiosPost.post(`admin-api/brand`, {...data, media_id: id.data.id}).then(_ => {
                    update()
                    loading(false)
                })
            })
            .catch(reject)
    }

    function update1(data) {
        loading(true)
        API.updateImage({
            image,
            media_id: one_brand[0].media_id
        }).then(id => {
            axiosPost.post(`admin-api/brand/${brand_id}`, {...data, media_id: id.data.id}).then(_ => {
                update()
                loading(false)
            })
        })
    }
    function update2(data) {
        loading(true)
        axiosPost.post(`admin-api/brand/${brand_id}`, data)
            .then(_ => {
                update()
                loading(false)
            })
    }

    const updateFunction = async (data) => {
        loading(true)
        image ? update1(data) : update2(data)
    }

    const deleteFunction = async () => {
        await axiosPost.delete(`admin-api/brand/${brand_id}`).then(update);
    }
    const createData = {
        category_id,
        is_active: 'yes',
        favorite: 'yes',
        translations: [
            {
                lang_code: 'am',
                title: '',
                description: ''
            },
            {
                lang_code: 'en',
                title: '',
                description: ''
            },
            {
                lang_code: 'ru',
                title: '',
                description: ''
            }
        ],
        social_networks: [
            {
                social_network_code: 'instagram',
                link: '',
            },
            {
                social_network_code: 'facebook',
                link: '',
            },
            {
                social_network_code: 'website',
                link: '',
            },
        ],
    }
    const formik = useFormik({
        initialValues: createData,
        onSubmit: () => {
            path ? postFunction(formik.values) : updateFunction(formik.values)
        },
    });

    useEffect(() => {
        !path && formik.setValues(one_brand[0]);
    }, [one_brand])

    return (
        <div className='form-div'>
            <h1>Brand</h1>
            <form encType='multipart/form-data' className='new-brand-form' onSubmit={formik.handleSubmit}>
                <FormikProvider value={formik}>
                    <div className='main'>
                        <div className='choice'>
                            <span className='file'>
                                <b>Image: </b>
                                <input required={path} type='file'
                                       onChange={(e) => setImage(e.currentTarget.files[0])}/>
                            </span>
                            <SelectComponent cls='is-active' b='Is Active: ' name='is_active' options={[
                                {value: 'yes', content: 'yes'},
                                {value: 'no', content: 'no'}
                            ]}/>
                            <SelectComponent cls='favorite' b='Favorite: ' name='favorite' options={[
                                {value: 'yes', content: 'yes'},
                                {value: 'no', content: 'no'}
                            ]}/>
                        </div>
                        <div className='box'>
                            <FieldSetComponent
                                legend={'AM'}
                                name1={'translations[0][title]'}
                                name2={'translations[0][description]'}
                                value1={formik.values?.translations?.[0]['title']}
                                value2={formik.values?.translations?.[0]['description']}
                                label1={'title'}
                                label2={'description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                            <FieldSetComponent
                                legend={'EN'}
                                name1={'translations[1][title]'}
                                name2={'translations[1][description]'}
                                value1={formik.values?.translations?.[1]['title']}
                                value2={formik.values?.translations?.[1]['description']}
                                label1={'title'}
                                label2={'description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                            <FieldSetComponent
                                legend={'RU'}
                                name1={'translations[2][title]'}
                                name2={'translations[2][description]'}
                                value1={formik.values?.translations?.[2]['title']}
                                value2={formik.values?.translations?.[2]['description']}
                                label1={'title'}
                                label2={'description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                        </div>
                        <div className='box'>
                            <FieldSetComponent
                                legend={'Social-1'}
                                name1={'social_networks[0][social_network_code]'}
                                name2={'social_networks[0][link]'}
                                value1={'instagram'}
                                value2={formik.values?.social_networks?.[0]['link']}
                                label1={'social name'}
                                label2={'social link'}
                                onChange={formik.handleChange}
                            />
                            <FieldSetComponent
                                legend={'Social-2'}
                                name1={'social_networks[1][social_network_code]'}
                                name2={'social_networks[1][link]'}
                                value1={'facebook'}
                                value2={formik.values?.social_networks?.[1]['link']}
                                label1={'social name'}
                                label2={'social link'}
                                onChange={formik.handleChange}
                            />
                            <FieldSetComponent
                                legend={'Website'}
                                name1={'social_networks[2][social_network_code]'}
                                name2={'social_networks[2][link]'}
                                value1={'website'}
                                value2={formik.values?.social_networks?.[2]['link']}
                                label1={'website name'}
                                label2={'social link'}
                                onChange={formik.handleChange}
                            />
                        </div>
                    </div>
                </FormikProvider>

                {(!path && (
                    <span className='buttons'>
                        <Button
                            type="submit"
                            className='form-send'>
                            Update
                        </Button>
                        <Button
                            type="button"
                            className='delete'
                            onClick={deleteFunction}>
                            Delete
                        </Button>
                    </span>
                ))}
                {(path && (
                    <Button
                        className='form-send'
                        type='submit'>
                        Create Brand
                    </Button>
                ))}
            </form>
        </div>
    );
}