import './login.scss';
import {useFormik} from "formik";
import axios from "axios";
import {FieldSetComponent} from "../../components/FieldSet";
import {useNavigate} from "react-router-dom";
import {useDispatch, useSelector} from "react-redux";
import {updateAdmin} from "../../Redux/getAdmin/slice";
import {loading, reject} from "../../helpers/loading";

export function Login() {
    const navigate = useNavigate()
    const {isAdmin} = useSelector(state => state.admin);
    const dispatch = useDispatch()
    const formik = useFormik({
        initialValues: {
            email: '',
            password: ''
        },
        onSubmit: async (values) => {
            loading(true)
            await axios.post(`${process.env.REACT_APP_BASE_URL}admin-api/auth/login`, values)
                .then(data => {
                    localStorage.setItem('admin', data.data.data.token);
                    dispatch(updateAdmin(localStorage.getItem('admin')))
                    navigate('/newProduct')
                    loading(false)
                })
                .catch(_ => {
                    formik.values.email = ''
                    formik.values.password = ''
                    reject()
                })
        }
    })
    return (
        <>
            {!isAdmin ? <form className='admin-login' onSubmit={formik.handleSubmit}>
                <FieldSetComponent
                    cls={'login'}
                    name1={'email'}
                    name2={'password'}
                    value1={formik.values.email}
                    value2={formik.values.password}
                    label1={'Email'}
                    label2={'Password'}
                    onChange={formik.handleChange}
                    onChange2={formik.handleChange}
                    button={true}
                />
            </form> : <div className='token'></div>}
        </>
    )
}