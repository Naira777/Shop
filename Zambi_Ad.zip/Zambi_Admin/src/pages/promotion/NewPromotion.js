import Button from "@mui/material/Button";
import {FormikProvider, useFormik} from "formik";
import {useDispatch, useSelector} from "react-redux";
import {SelectComponent} from "../../components/SelectComponent";
import {FieldSetComponent} from "../../components/FieldSet";
import axiosPost from "../../helpers/axios/axiosPost";
import {changePromotionId} from "../../Redux/getPromotion/slice";
import {API} from "../../Redux/API";
import {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";
import {loading, reject} from "../../helpers/loading";

export function NewPromotion() {
    const {promotion_id, one_promotion_data} = useSelector(state => state.promotion);

    const path = window.location.pathname === '/newPromotion';
    const dispatch = useDispatch();
    const navigate = useNavigate()
    const [image, setImage] = useState(null);
    const update = () => {
        dispatch(changePromotionId(null));
        dispatch(API.getPromotion());
        navigate('/editPromotion')
    }

    function update1(data) {
        loading(true)
        API.updateImage({image, media_id: one_promotion_data.media_id})
            .then(id => {
                axiosPost.post(`admin-api/promotion/${promotion_id}`, {...data, media_id: id.data.id}).then(_ => {
                    update()
                    loading(false)
                })
            })
    }

    function update2(data) {
        loading(true)
        axiosPost.post(`admin-api/promotion/${promotion_id}`, data)
            .then(_ => {
                update()
                loading(false)
            })
    }

    const postFunction = (data) => {
        loading(true)
        API.uploadImage({image}).then(id => {
            axiosPost.post('admin-api/promotion', {...data, media_id: id.data.id})
                .then(_ => {
                    update()
                    loading(false)
                })
                .catch(reject)
        })
    }
    const updateFunction = (data) => image ? update1(data) : update2(data)
    const deleteFunction = () => {
        loading(true)
        const del = window.confirm('Delete?')
        del && axiosPost.delete(`admin-api/promotion/${promotion_id}`)
            .then(_ => {
                update()
                loading(false)
            })
    }
    const formik = useFormik({
        initialValues: {
            id: promotion_id,
            is_active: 'yes',
            translations: [
                {
                    lang_code: 'am',
                    title: '',
                    description: ''
                },
                {
                    lang_code: 'en',
                    title: '',
                    description: ''
                },
                {
                    lang_code: 'ru',
                    title: '',
                    description: ''
                }
            ],
            status: 'not_read'
        },

        onSubmit: () => {
            path ? postFunction(formik.values) : updateFunction(formik.values);
        }
    })
    useEffect(() => {
        !path && formik.setValues(one_promotion_data)
    }, [one_promotion_data])

    return (
        <div className='form-div'>
            <h1>Promotion</h1>
            <form className='new-brand-form' onSubmit={formik.handleSubmit}>
                <div className='main'>
                    <FormikProvider value={formik}>
                        <div className='choice'>
                            <span className='file'>
                                <b>Image: </b>
                                <input type='file' name='image' required={path}
                                       onChange={(e) => setImage(e.currentTarget.files[0])}/>
                            </span>
                            <SelectComponent cls='is-active' b='Is Active: ' name='is_active' options={[
                                {value: 'yes', content: 'yes'},
                                {value: 'no', content: 'no'}
                            ]}/>
                            <SelectComponent cls='status' b='status: ' name='status' options={[
                                {value: 'not_read', content: 'not read'},
                                {value: 'read', content: 'read'},
                                {value: 'default', content: 'default'}
                            ]}/>
                        </div>
                        <div className='box'>
                            <FieldSetComponent
                                legend={'AM'}
                                name1={'translations[0][title]'}
                                name2={'translations[0][description]'}
                                value1={formik.values?.translations?.[0]['title']}
                                value2={formik.values?.translations?.[0]['description']}
                                label1={'title'}
                                label2={'description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                            <FieldSetComponent
                                legend={'EN'}
                                name1={'translations[1][title]'}
                                name2={'translations[1][description]'}
                                value1={formik.values?.translations?.[1]['title']}
                                value2={formik.values?.translations?.[1]['description']}
                                label1={'title'}
                                label2={'description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                            <FieldSetComponent
                                legend={'RU'}
                                name1={'translations[2][title]'}
                                name2={'translations[2][description]'}
                                value1={formik.values?.translations?.[2]['title']}
                                value2={formik.values?.translations?.[2]['description']}
                                label1={'title'}
                                label2={'description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                        </div>
                    </FormikProvider>
                </div>
                {(!path && <span className='buttons'>
                                    <Button
                                        type='submit'
                                        className='form-send'>
                                        Update
                                    </Button>
                                    <Button
                                        className='delete'
                                        onClick={deleteFunction}>
                                        Delete
                                    </Button>
                    </span>
                )}
                {(path && <Button
                        className='form-send'
                        type='submit'>
                        Create Promotion
                    </Button>
                )}
            </form>
        </div>
    );
}