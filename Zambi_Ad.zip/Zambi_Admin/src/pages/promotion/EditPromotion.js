import {useDispatch, useSelector} from "react-redux";
import Button from "@mui/material/Button";

import {NewPromotion} from "./NewPromotion";
import {changePromotionId} from "../../Redux/getPromotion/slice";
import {API} from "../../Redux/API";
import {useEffect} from "react";

export function EditPromotion() {
    const {promotion_data, promotion_id} = useSelector(state => state.promotion)
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(API.getPromotion());
    }, [dispatch])

    return (
        <>
            {!promotion_id && <div className='brand-list'>
                <h1>Promotion</h1>
                {promotion_data.length ? promotion_data.map(item => <Button
                        key={item.id}
                        variant="outlined"
                        onClick={() => {
                            dispatch(changePromotionId(item.id))
                            dispatch(API.getOnePromotion(item.id))
                        }}>
                        {item.translation.title}
                    </Button>)
                    : <h2 className='empty'>Empty</h2>}
            </div>}
            {promotion_id && <NewPromotion/>}
        </>
    );
}