import {useDispatch, useSelector} from "react-redux";
import {useEffect} from "react";
import {API} from "../../Redux/API";

export function Permissions() {
    const {permission_data} = useSelector(state => state.permission)
    const dispatch = useDispatch()
    useEffect(() => {
        dispatch(API.getPermission())
    }, [dispatch]);

    return (
        <div className='permission-list'>
            {permission_data?.map(item => (
                <div key={item.id} className='permission'>
                    <h2><b>Guard name: </b> {item.guard_name}</h2>
                    <h2><b>Name: </b> {item.name}</h2>
                </div>
            ))}
        </div>
    );
}