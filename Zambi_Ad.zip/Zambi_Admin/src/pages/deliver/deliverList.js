import {useDispatch, useSelector} from "react-redux";
import axios from "../../helpers/axios/axiosPost";
import '../users/user.scss';
import {useEffect, useState} from "react";
import {API} from "../../Redux/API";
import {Button} from "@mui/material";
import {loading, reject} from "../../helpers/loading";

export function DeliverList() {
    const dispatch = useDispatch();
    const {deliver_data} = useSelector(state => state.deliver);
    const updateFunction = (id, price) => {
        loading(true)
        axios.put(`admin-api/delivery-type/${id}`, {price})
            .then(_ => {
                dispatch(API.getDeliver())
                loading(false)
            })
            .catch(reject)
    }

    useEffect(() => {
        dispatch(API.getDeliver())
    }, [dispatch]);

    return (
        <div className='user-list'>
            {deliver_data.map(deliver => (
                <Price deliver={deliver} updateFunction={updateFunction} key={deliver.id}/>
            ))}
        </div>
    )
}

const Price = ({deliver, updateFunction}) => {
    const [price, setPrice] = useState('');

    useEffect(() => {
        setPrice("")
    }, [deliver]);


    return (
        <div key={deliver.id} className='deliver'>
            <h2><b>Code: </b>{deliver.code}</h2>
            <h2><b>Price: </b>{deliver.price}</h2>
            <h2><b>Should be sync: </b>{deliver.should_be_sync}</h2>
            <div className='price-update'>
                <input required
                       step='50'
                       type='number'
                       value={price}
                       placeholder='New price'
                       onChange={(e) => setPrice(e.target.value)}/>
                <Button variant="contained" onClick={() => updateFunction(deliver.id, price)}>
                    Update
                </Button>
            </div>
        </div>
    )
}