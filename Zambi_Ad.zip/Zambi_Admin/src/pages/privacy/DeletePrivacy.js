import {useDispatch, useSelector} from "react-redux";
import Button from '@mui/material/Button';
import {changePrivacyId} from "../../Redux/getPrivacy/slice";
import {EditPrivacy} from "./EditPrivacy";
import axiosPost from "../../helpers/axios/axiosPost";
import {API} from "../../Redux/API";
import {useEffect} from "react";
import {loading, reject} from "../../helpers/loading";

export function DeletePrivacy() {
    const update = () => {
        dispatch(API.getPrivacy())
    }
    const deleteFunction = (id) => {
        const del = window.confirm('Delete?')
        if (del) {
            loading(true)
            axiosPost.delete(`admin-api/privacy/${id}`)
                .then(_ => {
                    update()
                    loading(false)
                })
                .catch(reject)
        }
    }
    const {privacy_data, privacy_id, privacyEdit} = useSelector(state => state.privacy)
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(API.getPrivacy());
    }, [dispatch])
    return <>
        {!privacyEdit &&
            <>
                {!privacy_id && <div className='privacy-list'>
                    {privacy_data.map(item => <Button
                        key={item.id}
                        variant="outlined"
                        onClick={() => dispatch(changePrivacyId(item.id))}
                    >
                        {item.type}
                    </Button>)}
                </div>}
                {privacy_id && <div className='privacy-list'>
                    {!privacy_data[privacy_id - 1].translations.length && <h1 className='empty'>Empty</h1>}
                    {privacy_data[privacy_id - 1]?.translations?.map(item =>
                        <Button
                            key={item.id}
                            variant="outlined"
                            onClick={() => {
                                deleteFunction(item.id)
                            }}
                        >
                            {item.description}
                        </Button>
                    )}

                </div>}
            </>
        }
        {privacyEdit && <EditPrivacy/>}
    </>
        ;
}
