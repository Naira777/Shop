import Button from "@mui/material/Button";
import {FormikProvider, useFormik} from "formik";
import {useDispatch, useSelector} from "react-redux";
import {FieldSetComponent} from "../../components/FieldSet";
import axiosPost from "../../helpers/axios/axiosPost";
import {changePrivacyId} from "../../Redux/getPrivacy/slice";
import {API} from "../../Redux/API";
import {loading, reject} from "../../helpers/loading";

export function EditPrivacy() {
    const dispatch = useDispatch()
    const update = () => {
        dispatch(changePrivacyId(null))
        dispatch(API.getPrivacy())
    }
    const {privacy_id} = useSelector(state => state.privacy);
    const updateFunction = (data) => {
        loading(true)
        axiosPost.post(`admin-api/privacy`, data)
            .then(_ => {
                update()
                loading(false)
            })
            .catch(reject)
    }
    const formik = useFormik({
        initialValues: {
            privacy_id,
            translations: [
                {
                    lang_code: 'am',
                    title: '',
                    description: '',
                },
                {
                    lang_code: 'en',
                    title: '',
                    description: '',
                },
                {
                    lang_code: 'ru',
                    title: '',
                    description: '',
                }
            ]
        },
        onSubmit: () => updateFunction(formik.values)
    })

    return (
        <div className='form-div'>
            <form className='new-privacy-form' onSubmit={formik.handleSubmit}>
                <div className='main'>
                    <FormikProvider value={formik}>
                        <div className='box privacy'>
                            <legend>Translations</legend>
                            <FieldSetComponent
                                name1={'translations[0][title]'}
                                name2={'translations[0][description]'}
                                value1={formik.values.translations[0]['title']}
                                label1={'AM title'}
                                label2={'AM description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                            <FieldSetComponent
                                name1={'translations[1][title]'}
                                name2={'translations[1][description]'}
                                value1={formik.values.translations[1]['title']}
                                value2={formik.values.translations[1]['description']}
                                label1={'EN title'}
                                label2={'EN description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                            <FieldSetComponent
                                name1={'translations[2][title]'}
                                name2={'translations[2][description]'}
                                value1={formik.values.translations[2]['title']}
                                label1={'RU title'}
                                label2={'RU description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                            <Button
                                style={{margin: '0 auto', display: 'block'}}
                                className='form-send'
                                type='submit'>
                                Update
                            </Button>
                        </div>
                    </FormikProvider>
                </div>
            </form>
        </div>
    );
}