import {useDispatch, useSelector} from "react-redux";
import Button from '@mui/material/Button';
import {changePrivacyId} from "../../Redux/getPrivacy/slice";
import {EditPrivacy} from "./EditPrivacy";
import {API} from "../../Redux/API";
import {useEffect} from "react";

export function PrivacyList() {
    const {privacy_data, privacy_id} = useSelector(state => state.privacy)
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(API.getPrivacy());
    }, [])

    return <>
        {!privacy_id && <div className='privacy-list'>
            {privacy_data.map(item => <Button
                key={item.id}
                variant="outlined"
                onClick={() => dispatch(changePrivacyId(item.id))}
            >
                {item.type}
            </Button>)}
        </div>}
        {privacy_id && <EditPrivacy/>}
    </>
}
