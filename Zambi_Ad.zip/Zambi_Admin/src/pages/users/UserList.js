import {useDispatch, useSelector} from "react-redux";
import axios from "../../helpers/axios/axiosPost";
import './user.scss';
import {useEffect} from "react";
import {API} from "../../Redux/API";
import {Button} from "@mui/material";

export function UserList() {
    const dispatch = useDispatch();
    const {user_data} = useSelector(state => state.user);
    const blockFunction = (id) => axios.post(`admin-api/block/${id}`).then(_ => dispatch(API.getUser()));
    const unblockFunction = (id) => axios.post(`admin-api/unblock/${id}`).then(_ => dispatch(API.getUser()));
    useEffect(() => {
        dispatch(API.getUser())
    }, [dispatch])

    return (
        <div className='user-list'>
            <h1>Users</h1>
            {user_data.map(user => (
                <div key={user.id} className='user'>
                    <h2><b>User name: </b> {user.name}</h2>
                    <h2><b>Last name: </b> {user.last_name}</h2>
                    <h2><b>Phone number: </b> {user.phone_number}</h2>
                    <h2><b>Is verified: </b> {user.isVerified}</h2>
                    <h2><b>Is registered: </b> {user.is_registered}</h2>
                    <h2><b>Blocked: </b> {user.blocked}</h2>
                    <h2><b>Email: </b> {user.email}</h2>
                    <div className='buttons'>
                        <Button variant="contained"
                                className={user.blocked === 'no' ? 'block' : 'unblock'}
                                onClick={() => user.blocked === 'no' ? blockFunction(user.id) : unblockFunction(user.id)}>
                            {user.blocked === 'no' ? 'Block' : 'Unblock'}
                        </Button>
                    </div>
                </div>
            ))}
        </div>
    )
}