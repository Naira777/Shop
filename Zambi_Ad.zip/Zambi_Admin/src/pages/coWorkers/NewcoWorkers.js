import {FormikProvider, useFormik} from "formik";
import {useDispatch, useSelector} from "react-redux";
import axios from "../../helpers/axios/axiosPost";
import {FieldSetComponent} from "../../components/FieldSet";
import {SelectComponent2} from "../../components/SelectComponent2";
import {API} from "../../Redux/API";
import {useEffect, useState} from "react";
import {changeCoWorkerId} from "../../Redux/getCoWorker/slice";
import {useNavigate} from "react-router-dom";
import {Button} from "@mui/material";
import './worker.scss'
import {loading, reject} from "../../helpers/loading";

export function NewCoWorkers() {
    const navigate = useNavigate()
    const path = window.location.pathname === '/newCoWorker';
    const dispatch = useDispatch()
    const [image, setImage] = useState();
    const {work_category} = useSelector(state => state.workCategoryHours)
    const {one_co_worker_data, co_worker_id} = useSelector(state => state.coWorker)
    useEffect(() => {
        dispatch(API.getWorkCategory());
        dispatch(API.getWorkingHours());
    }, [dispatch])
    const update = () => {
        dispatch(API.getWorkCategory());
        dispatch(API.getCoWorker())
        dispatch(API.getWorkingHours());
        dispatch(changeCoWorkerId(null));
    }

    function update1(data) {
        loading(true)
        API.updateImage({image, media_id: one_co_worker_data.image_id}).then(id => {
            axios.post(`admin-api/co_worker/${co_worker_id}`, {...data, media_id: id.data.id})
                .then(_ => {
                    update()
                    loading(false)
                })
                .catch(reject)
        })
    }

    function update2(data) {
        loading(true)
        axios.post(`admin-api/co_worker/${co_worker_id}`, data)
            .then(_ => {
                update()
                loading(false)
            })
            .catch(reject)
    }

    const postFunction = async (data) => {
        loading(true)
        API.uploadImage({image}).then(id => {
            axios.post('admin-api/co_worker', {...data, media_id: id.data.id})
                .then(_ => {
                    update();
                    navigate('/editCoWorker')
                    loading(false)
                })
                .catch(reject)
        })
    }
    const updateFunction = async (data) => image ? update1(data) : update2(data)
    const deleteFunction = async () => {
        loading(true)
        await axios.delete(`admin-api/co_worker/${co_worker_id}`).then(_ => {
            update()
            loading(false)
        });

    }
    const formik = useFormik({
        initialValues: {
            work_category_id: 1,
            translations: [
                {
                    lang_code: 'am',
                    first_name: '',
                    last_name: '',
                    description: '',
                },
                {
                    lang_code: 'en',
                    first_name: '',
                    last_name: '',
                    description: '',
                },
                {
                    lang_code: 'ru',
                    first_name: '',
                    last_name: '',
                    description: '',
                }
            ],
        },

        onSubmit: async () => {
            path ? await postFunction(formik.values) : await updateFunction(formik.values)
        },
    });

    useEffect(() => {
        !path && formik.setValues(one_co_worker_data)
    }, [one_co_worker_data])

    return (
        <div className='form-div'>
            <form className='new-co-worker' onSubmit={formik.handleSubmit}>
                <FormikProvider value={formik}>
                    <div className='main'>
                        <div className='choice'>
                            <span className='file'>
                                <b>Image: </b>
                                <input required={path} type='file'
                                       onChange={(e) => setImage(e.currentTarget.files[0])}/>
                            </span>
                            <SelectComponent2 cls='work-category-id'
                                              b='Work category: '
                                              name='work_category_id'
                                              handleChange={formik.handleChange}
                                              options={work_category}/>
                        </div>
                        <div className='box'>
                            <legend>Translation</legend>
                            <FieldSetComponent
                                name1={'translations[0][first_name]'}
                                name2={'translations[0][last_name]'}
                                name3={'translations[0][description]'}
                                value1={formik.values?.translations?.[0]['first_name']}
                                value2={formik.values?.translations?.[0]['last_name']}
                                value3={formik.values?.translations?.[0]['description']}
                                label1={'AM first_name'}
                                label2={'EN last_name'}
                                label3={'RU description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                                onChange3={formik.handleChange}
                            />
                            <FieldSetComponent
                                name1={'translations[1][first_name]'}
                                name2={'translations[1][last_name]'}
                                name3={'translations[1][description]'}
                                value1={formik.values?.translations?.[1]['first_name']}
                                value2={formik.values?.translations?.[1]['last_name']}
                                value3={formik.values?.translations?.[1]['description']}
                                label1={'AM first_name'}
                                label2={'EN last_name'}
                                label3={'RU description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                                onChange3={formik.handleChange}
                            />
                            <FieldSetComponent
                                name1={'translations[2][first_name]'}
                                name2={'translations[2][last_name]'}
                                name3={'translations[2][description]'}
                                value1={formik.values?.translations?.[2]['first_name']}
                                value2={formik.values?.translations?.[2]['last_name']}
                                value3={formik.values?.translations?.[2]['description']}
                                label1={'AM first_name'}
                                label2={'EN last_name'}
                                label3={'RU description'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                                onChange3={formik.handleChange}
                            />
                            {(path && <Button
                                    className='form-send'
                                    type='submit'>
                                    Create Co Worker
                                </Button>
                            )}
                            {(!path && (
                                <span className='buttons'>
                                    <Button
                                        type="submit"
                                        className='form-send'>
                                    Update
                                    </Button>
                                    <Button
                                        type="button"
                                        className='delete'
                                        onClick={deleteFunction}
                                    >
                                    Delete
                                    </Button>
                                    </span>
                            ))}
                        </div>
                    </div>
                </FormikProvider>
            </form>
        </div>
    );
}