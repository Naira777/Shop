import {useDispatch, useSelector} from "react-redux";
import {changeCoWorkerId} from "../../Redux/getCoWorker/slice";
import {NewCoWorkers} from "./NewcoWorkers";
import {API} from "../../Redux/API";
import {useEffect} from "react";

export function CoWorkerList() {
    const {co_worker_data, co_worker_id} = useSelector(state => state.coWorker)
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(API.getCoWorker());
    }, [dispatch])

    return (
        <>
            {!co_worker_id && <div className='coWorker-list'>
                {co_worker_data?.map(item => (
                    <div key={item.id} className='coWorker-item' onClick={() => {
                        dispatch(changeCoWorkerId(item.id))
                        dispatch(API.getOneCoWorker(item.id))
                    }}>
                        <img src={`${process.env.REACT_APP_BASE_URL}${item.image.big_image}`}
                             alt='Co_Worker_image :('/>
                        <h5>First name: <b>{item.translation.first_name}</b></h5>
                        <h5>Description: <b>{item.translation.description}</b></h5>
                        <h5>Profession: <b>{item.profession.code}</b></h5>
                    </div>))}
            </div>}
            {co_worker_id && <NewCoWorkers/>}
        </>
    );
}