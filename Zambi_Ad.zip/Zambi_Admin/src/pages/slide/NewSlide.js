import Button from "@mui/material/Button";
import {FormikProvider, useFormik} from "formik";
import {useDispatch, useSelector} from "react-redux";
import axios from "../../helpers/axios/axiosPost";
import {FieldSetComponent} from "../../components/FieldSet";
import './slide.scss';
import {API} from "../../Redux/API";
import {useEffect, useState} from "react";
import {changeSlideId} from "../../Redux/getSlides/slice";
import {useNavigate} from "react-router-dom";
import {loading, reject} from "../../helpers/loading";

export function NewSlide() {
    const [order, setOrder] = useState(0);
    const path = window.location.pathname === '/newSlide';
    const navigate = useNavigate();
    const dispatch = useDispatch()
    const update = () => {
        dispatch(API.getSlide());
        dispatch(changeSlideId(null));
    }
    const {slide_id, one_slide_data, slide_data} = useSelector(state => state.slide);
    const [image, setImage] = useState();
    const postFunction = (data) => {
        const newOrder = slide_data.map(item => item.order).sort((a, b) => b - a)[0] + 1;
        setOrder(newOrder);
        loading(true)
        API.uploadImage({image}).then(id => {
            axios.post(`admin-api/slide/item`, {
                ...data,
                media_id: id.data.id,
                order: newOrder,
            })
                .then(_ => {
                    update();
                    navigate('/editSlide');
                    loading(false)
                })
                .catch(reject)
        })
    }

    function update1(data) {
        loading(true)
        API.updateImage({image, media_id: one_slide_data?.media.id})
            .then(id => {
                axios.post(`admin-api/slide/${slide_id}`, {
                    ...data,
                    media_id: id.data.id,
                    order
                }).then(_ => {
                    update()
                    loading(false)
                })
            })
            .catch(reject)
    }

    function update2(data) {
        loading(true)
        axios.post(`admin-api/slide/${slide_id}`, {...data, order})
            .then(_ => {
                update()
                loading(false)
            })
            .catch(reject)
    }

    const updateFunction = (data) => image ? update1(data) : update2(data)
    const deleteFunction = () => {
        const del = window.confirm('Delete?')
        loading(true)
        del && axios.delete(`admin-api/slide/${slide_id}`).then(_ => {
            update()
            loading(false)
        })
    }

    const formik = useFormik({
        initialValues: {
            translations: [
                {
                    lang_code: 'am',
                    title: '',
                },
                {
                    lang_code: 'en',
                    title: '',
                },
                {
                    lang_code: 'ru',
                    title: '',
                }
            ]
        },
        onSubmit: () => {
            path ? postFunction(formik.values) : updateFunction(formik.values);
        }
    })
    useEffect(() => {
        dispatch(API.getSlide())
        if (!path) {
            formik.setValues(one_slide_data)
            formik.setFieldValue('media_id', one_slide_data?.media?.id)
            setOrder(slide_data.map(item => item.order).sort((a, b) => b - a)[0] + 1)
        }
    }, [one_slide_data]);

    return (
        <div className='form-div'>
            <form className='new-brand-form' onSubmit={formik.handleSubmit}>
                <div className='main'>
                    <FormikProvider value={formik}>
                        <div className='choice'>
                            <span className='file'>
                                <b>Image: </b>
                                <input type='file' name='image' required={path}
                                       onChange={(e) => setImage(e.currentTarget.files[0])}/>
                            </span>
                        </div>
                        <div className='box slide'>
                            <FieldSetComponent
                                legend={'AM'}
                                name1={'translations[0][title]'}
                                value1={formik.values?.translations?.[0]['title']}
                                label1={'title'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                            <FieldSetComponent
                                legend={'EN'}
                                name1={'translations[1][title]'}
                                value1={formik.values?.translations?.[1]['title']}
                                label1={'title'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                            <FieldSetComponent
                                legend={'RU'}
                                name1={'translations[2][title]'}
                                value1={formik.values?.translations?.[2]['title']}
                                label1={'title'}
                                onChange={formik.handleChange}
                                onChange2={formik.handleChange}
                            />
                        </div>
                    </FormikProvider>
                </div>
                {(!path && (
                    <span className='buttons'>
                                    <Button
                                        className='form-send'
                                        type='submit'>
                                    Update
                                </Button>
                                    <Button
                                        className='delete'
                                        onClick={deleteFunction}>
                                    Delete
                                </Button>
                                </span>
                ))}
                {(path && <Button
                        className='form-send'
                        type='submit'>
                        Create Slide
                    </Button>
                )}
            </form>
        </div>
    );
}