import {useDispatch, useSelector} from "react-redux";
import {NewSlide} from "./NewSlide";
import {API} from "../../Redux/API";
import {useEffect} from "react";
import {changeSlideId} from "../../Redux/getSlides/slice";

export function SlideList() {
    const {slide_id, slide_data} = useSelector(state => state.slide);
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(API.getSlide());
    }, [])

    return (
        <>
            {!slide_id && <div className='list2'>
                <div className='slide-list'>
                    {slide_data?.map(item => <div key={item.id} className='slide-item' onClick={() => {
                        dispatch(changeSlideId(item.id));
                        dispatch(API.getOneSlide(item.id));
                    }}>
                        <img src={`${process.env.REACT_APP_BASE_URL}${item.media?.big_image}`}
                             alt='Slide_image :('/>
                        <h5>Title: <b>{item.translations[0].title}</b></h5>
                    </div>)}
                </div>
            </div>
            }
            {slide_id && <NewSlide/>}
        </>
    );
}

