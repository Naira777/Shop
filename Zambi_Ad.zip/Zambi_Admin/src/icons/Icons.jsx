import LocalMallIcon from "@mui/icons-material/LocalMall";
import EditIcon from "@mui/icons-material/Edit";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import AddIcon from '@mui/icons-material/Add';
import WarehouseIcon from '@mui/icons-material/Warehouse';
import WarehouseTwoToneIcon from '@mui/icons-material/WarehouseTwoTone';
import PrivacyTipIcon from '@mui/icons-material/PrivacyTip';
import StarsOutlinedIcon from '@mui/icons-material/StarsOutlined';
import FoodBankIcon from '@mui/icons-material/FoodBank';
import QuestionMarkSharpIcon from '@mui/icons-material/QuestionMarkSharp';
import DeleteIcon from '@mui/icons-material/Delete';
import FiberNewIcon from "@mui/icons-material/FiberNew";
import LoginIcon from "@mui/icons-material/Login";
import DiscountIcon from "@mui/icons-material/Discount";
import PhotoSizeSelectActualIcon from "@mui/icons-material/PhotoSizeSelectActual";
import AnnouncementIcon from '@mui/icons-material/Announcement';
import AllInboxIcon from '@mui/icons-material/AllInbox';
import DeliveryDiningIcon from '@mui/icons-material/DeliveryDining';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import EmailIcon from '@mui/icons-material/Email';
import PriceChangeIcon from '@mui/icons-material/PriceChange';
import PersonOffIcon from '@mui/icons-material/PersonOff';
import LogoutIcon from '@mui/icons-material/Logout';
import LocalOfferTwoToneIcon from '@mui/icons-material/LocalOfferTwoTone';
import LocalOfferIcon from '@mui/icons-material/LocalOffer';

export {
    LocalMallIcon,
    EditIcon,
    AddCircleOutlineIcon,
    WarehouseIcon,
    AddIcon,
    WarehouseTwoToneIcon,
    PrivacyTipIcon,
    StarsOutlinedIcon,
    FoodBankIcon,
    QuestionMarkSharpIcon,
    DeleteIcon,
    FiberNewIcon,
    LoginIcon,
    DiscountIcon,
    PhotoSizeSelectActualIcon,
    AnnouncementIcon,
    AllInboxIcon,
    DeliveryDiningIcon,
    LocalShippingIcon,
    EmailIcon,
    PersonOffIcon,
    PriceChangeIcon,
    LogoutIcon,
    LocalOfferTwoToneIcon,
    LocalOfferIcon
}